﻿import sys
import asyncio
from pathlib import Path
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parent
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from ai_connector import ultron_ai

app = FastAPI(title="ULTRON ZA17 AI Test")

class ChatRequest(BaseModel):
    message: str

@app.get("/api/health")
def health():
    return {"status": "online", "assistant": "ULTRON ZA17"}

@app.post("/api/chat")
async def chat(data: ChatRequest):
    message = data.message.strip()
    if not message:
        raise HTTPException(status_code=400, detail="Message cannot be empty")

    try:
        reply = await asyncio.to_thread(ultron_ai.chat, message)
        return {"reply": reply}
    except Exception as error:
        raise HTTPException(status_code=502, detail=str(error))
