from core.ai_engine import UltronAI

class WebUltronAI:
    def __init__(self):
        self.ai = UltronAI()

    def chat(self, message):
        return self.ai.get_response(message)

ultron_ai = WebUltronAI()
