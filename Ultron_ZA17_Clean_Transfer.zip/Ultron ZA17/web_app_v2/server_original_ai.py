﻿import sys
from pathlib import Path
from fastapi import FastAPI, HTTPException, Header
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parent.parent
BACKEND = Path(__file__).resolve().parent / "backend"

sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(BACKEND))

from ai_connector import ultron_ai

app = FastAPI(title="ULTRON ZA17")
app.mount("/static", StaticFiles(directory=Path(__file__).resolve().parent / "static"), name="static")

KEY = "CHANGE-THIS-KEY"

class Login(BaseModel):
    key: str

class Chat(BaseModel):
    message: str

@app.get("/")
def home():
    return FileResponse(Path(__file__).resolve().parent / "static" / "index.html")

@app.post("/api/login")
def login(data: Login):
    if data.key != KEY:
        raise HTTPException(401, "Incorrect access key")
    return {"ok": True}

@app.post("/api/chat")
async def chat(data: Chat, x_ultron_key: str = Header(default="")):
    if x_ultron_key != KEY:
        raise HTTPException(401, "Sign in again")
    if not data.message.strip():
        raise HTTPException(400, "Message cannot be empty")
    try:
        reply = await __import__("asyncio").to_thread(ultron_ai.chat, data.message)
        return {"reply": reply}
    except Exception as error:
        raise HTTPException(502, str(error))

@app.get("/api/health")
def health():
    return {"status": "online", "assistant": "ULTRON ZA17", "engine": "original"}

