﻿import sys
import os
import asyncio
from pathlib import Path
from fastapi import FastAPI, HTTPException, Header
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from ai_connector import ultron_ai

KEY = os.environ.get("ULTRON_WEB_KEY", "CHANGE-THIS-KEY")

app = FastAPI(title="ULTRON ZA17")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

class Chat(BaseModel):
    message: str
    history: list = Field(default_factory=list)

@app.get("/")
def home():
    return FileResponse(ROOT / "static" / "index.html")

@app.post("/api/chat")
async def chat(x: Chat, x_ultron_key: str = Header(default="")):
    if x_ultron_key != KEY:
        raise HTTPException(401, "Sign in again")
    if not x.message.strip():
        raise HTTPException(400, "Message cannot be empty")
    try:
        reply = await asyncio.to_thread(ultron_ai.chat, x.message)
        return {"reply": reply}
    except Exception as error:
        raise HTTPException(502, str(error))

@app.get("/api/health")
def health():
    return {"status": "online", "assistant": "ULTRON ZA17"}
