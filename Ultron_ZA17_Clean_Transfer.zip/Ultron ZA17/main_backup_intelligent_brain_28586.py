"""ULTRON ZA17 - Command Center Edition

A redesigned CustomTkinter interface that preserves the existing project modules.
The hero artwork is loaded from assets/ultron_hero.png. Hardware/home controls are
clearly marked as disconnected until their real interfaces are implemented.
"""

from __future__ import annotations

import math
import os
import random
import re
import threading
import time
import tkinter as tk
from pathlib import Path

import customtkinter as ctk

try:
    import speech_recognition as sr
except Exception:
    sr = None

try:
    from PIL import Image, ImageTk
except Exception:
    Image = ImageTk = None

try:
    from core.ai_engine import UltronAI
except Exception as exc:
    UltronAI = None
    AI_IMPORT_ERROR = exc
else:
    AI_IMPORT_ERROR = None

try:
    from core.voice_engine import UltronVoice
except Exception as exc:
    UltronVoice = None
    VOICE_IMPORT_ERROR = exc
else:
    VOICE_IMPORT_ERROR = None

try:
    from modules.robot_controller import RobotController
except Exception as exc:
    RobotController = None
    ROBOT_IMPORT_ERROR = exc
else:
    ROBOT_IMPORT_ERROR = None

try:
    from modules.system_operator import SystemOperator
except Exception as exc:
    SystemOperator = None
    SYSTEM_IMPORT_ERROR = exc
else:
    SYSTEM_IMPORT_ERROR = None

try:
    from modules.home_controller import HomeController
except Exception as exc:
    HomeController = None
    HOME_IMPORT_ERROR = exc
else:
    HOME_IMPORT_ERROR = None


ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")


class UltronApp(ctk.CTk):
    """Cinematic ULTRON command center with persistent modules and AI chat."""

    BG = "#050608"
    PANEL = "#090C11"
    PANEL_2 = "#0D1118"
    LINE = "#492014"
    ACCENT = "#FF5429"
    ACCENT_HOT = "#FF7842"
    ACCENT_DARK = "#8D2919"
    RED = "#F04445"
    GREEN = "#63E56F"
    TEXT = "#E9E9EC"
    MUTED = "#8A929C"
    DIM = "#4F5964"

    MODE_COLORS = {
        "IDLE": ACCENT,
        "LISTENING": "#FF9A36",
        "THINKING": "#F2C14E",
        "SPEAKING": "#FF4B55",
        "EXECUTING": "#FF7842",
        "ERROR": "#FF4242",
    }
    MODE_LABELS = {
        "IDLE": "SYSTEM STANDBY",
        "LISTENING": "VOICE INPUT ACTIVE",
        "THINKING": "NEURAL PROCESSING",
        "SPEAKING": "VOICE OUTPUT ACTIVE",
        "EXECUTING": "COMMAND EXECUTION",
        "ERROR": "SYSTEM ATTENTION REQUIRED",
    }

    MODULES = [
        ("CHAT AI", "◉"),
        ("VOICE CONTROL", "♫"),
        ("ROBOT CONTROL", "⌘"),
        ("HOME CONTROL", "⌂"),
        ("SYSTEM TOOLS", "⚙"),
        ("CODE ASSIST", "</>"),
        ("MORE", "▦"),
    ]

    def __init__(self):
        super().__init__()

        self.system_operator = SystemOperator() if SystemOperator else None
        self.home_controller = HomeController() if HomeController else None
        self.ai = UltronAI() if UltronAI else None
        self.robot = RobotController() if RobotController else None
        self.voice = UltronVoice() if UltronVoice else None

        self.mic_enabled = False
        self.listen_thread = None
        self.animation_frame = 0
        self.animation_mode = "IDLE"
        self._closing = False
        self._speech_monitor_running = False
        self._busy = False
        self.active_module = "CHAT AI"
        self.chat_history: list[tuple[str, str]] = []
        self.nav_buttons: dict[str, ctk.CTkButton] = {}
        self.status_value_labels: dict[str, ctk.CTkLabel] = {}
        self.chat = None
        self.entry = None
        self.send_button = None
        self.mic_button = None
        self._hero_source = None
        self._hero_photo = None
        self._hero_photo_size = None

        self.title("ULTRON ZA17 | AI COMMAND CENTER")
        self.geometry("1510x880")
        self.minsize(1080, 690)
        self.configure(fg_color=self.BG)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self._load_hero_art()
        self.create_interface()
        self.bind_all("<KeyPress>", self.handle_keypress, add="+")
        self.after(50, self.animate_interface)
        self.after(350, self._initial_status)

    # ------------------------------------------------------------------
    # INITIALIZATION AND SHARED UI HELPERS
    # ------------------------------------------------------------------

    def _load_hero_art(self):
        if Image is None:
            return
        path = Path(__file__).resolve().parent / "assets" / "ultron_hero.png"
        try:
            if path.exists():
                self._hero_source = Image.open(path).convert("RGBA")
        except Exception as error:
            print("ULTRON artwork load error:", error)

    def _panel(self, parent, title, height=None):
        panel = ctk.CTkFrame(
            parent,
            fg_color=self.PANEL,
            border_width=1,
            border_color=self.LINE,
            corner_radius=10,
            height=height or 100,
        )
        if height:
            panel.grid_propagate(False)
        panel.grid_columnconfigure(0, weight=1)
        heading = ctk.CTkLabel(
            panel,
            text=title,
            font=("Arial", 12, "bold"),
            text_color=self.ACCENT_HOT,
            anchor="w",
        )
        heading.grid(row=0, column=0, sticky="ew", padx=14, pady=(10, 5))
        return panel

    def _label(self, parent, text, size=10, color=None, bold=False, **kwargs):
        return ctk.CTkLabel(
            parent,
            text=text,
            font=("Arial", size, "bold" if bold else "normal"),
            text_color=color or self.TEXT,
            **kwargs,
        )

    def _initial_status(self):
        self.set_status("AI CORE", "INITIALIZED", self.GREEN)
        self.set_status(
            "VOICE OUTPUT",
            "LOADED" if self.voice else "UNAVAILABLE",
            self.GREEN if self.voice else self.RED,
        )
        self.set_status(
            "SYSTEM TOOLS",
            "READY" if self.system_operator else "UNAVAILABLE",
            self.GREEN if self.system_operator else self.RED,
        )
        self.set_status("MIC INPUT", "OFF", self.MUTED)
        self.set_status(
            "ROBOT LINK",
            "DISCONNECTED" if not getattr(self.robot, "connected", False) else "CONNECTED",
            self.MUTED if not getattr(self.robot, "connected", False) else self.GREEN,
        )

    def set_status(self, name, value, color=None):
        label = self.status_value_labels.get(name)
        if label and label.winfo_exists():
            label.configure(text=value, text_color=color or self.TEXT)

    def _clear_host(self):
        for child in self.module_host.winfo_children():
            child.destroy()
        self.chat = None
        self.entry = None
        self.send_button = None
        self.mic_button = None

    def _page_heading(self, parent, title, description):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.grid(row=0, column=0, sticky="ew", padx=16, pady=(12, 7))
        row.grid_columnconfigure(0, weight=1)
        self._label(row, title, 13, self.ACCENT_HOT, True, anchor="w").grid(
            row=0, column=0, sticky="w"
        )
        self._label(row, description, 9, self.MUTED, anchor="e").grid(
            row=0, column=1, sticky="e"
        )

    # ------------------------------------------------------------------
    # MAIN COMMAND-CENTER LAYOUT
    # ------------------------------------------------------------------

    def create_interface(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        top = ctk.CTkFrame(self, fg_color="#07090C", corner_radius=0, height=48)
        top.grid(row=0, column=0, sticky="ew")
        top.grid_propagate(False)
        top.grid_columnconfigure(1, weight=1)

        brand = ctk.CTkFrame(top, fg_color="transparent")
        brand.grid(row=0, column=0, sticky="w", padx=17, pady=6)
        self._label(brand, "◈", 19, self.ACCENT_HOT, True).pack(side="left", padx=(0, 9))
        self._label(brand, "ULTRON ZA17", 17, self.TEXT, True).pack(side="left")

        self.top_mode = self._label(
            top, "● SYSTEM ONLINE", 10, self.GREEN, True
        )
        self.top_mode.grid(row=0, column=1, sticky="e", padx=18)

        self.body = ctk.CTkFrame(self, fg_color="transparent")
        self.body.grid(row=1, column=0, sticky="nsew", padx=12, pady=(8, 6))
        self.body.grid_columnconfigure(0, minsize=218, weight=0)
        self.body.grid_columnconfigure(1, weight=1, minsize=440)
        self.body.grid_columnconfigure(2, minsize=220, weight=0)
        self.body.grid_rowconfigure(0, weight=1)

        self._create_left_column()
        self._create_center_column()
        self._create_right_column()
        self.show_module("CHAT AI")

        footer = ctk.CTkFrame(self, fg_color="#07090C", corner_radius=0, height=35)
        footer.grid(row=2, column=0, sticky="ew")
        footer.grid_propagate(False)
        footer.grid_columnconfigure(1, weight=1)
        self.footer_status = self._label(
            footer, "ULTRON ZA17  //  LOCAL COMMAND CENTER", 9, self.MUTED, True
        )
        self.footer_status.grid(row=0, column=0, sticky="w", padx=16)
        self.footer_wave = tk.Canvas(
            footer, height=31, bg="#07090C", highlightthickness=0, bd=0
        )
        self.footer_wave.grid(row=0, column=1, sticky="ew", padx=10)
        self.footer_right = self._label(
            footer, "ROBOT HARDWARE: NOT CONNECTED", 9, self.ACCENT_HOT, True
        )
        self.footer_right.grid(row=0, column=2, sticky="e", padx=16)

    def _create_left_column(self):
        self.left_column = ctk.CTkFrame(self.body, fg_color="transparent")
        self.left_column.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        self.left_column.grid_columnconfigure(0, weight=1)
        self.left_column.grid_rowconfigure(0, weight=0)
        self.left_column.grid_rowconfigure(1, weight=1)
        self.left_column.grid_rowconfigure(2, weight=0)

        status_card = self._panel(self.left_column, "SYSTEM STATUS", 218)
        status_card.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        status_rows = [
            ("AI CORE", "STARTING"),
            ("VOICE OUTPUT", "STARTING"),
            ("MIC INPUT", "OFF"),
            ("SYSTEM TOOLS", "STARTING"),
            ("ROBOT LINK", "DISCONNECTED"),
        ]
        for index, (name, value) in enumerate(status_rows, start=1):
            line = ctk.CTkFrame(status_card, fg_color="transparent")
            line.grid(row=index, column=0, sticky="ew", padx=13, pady=3)
            line.grid_columnconfigure(1, weight=1)
            self._label(line, "●", 10, self.GREEN, True).grid(row=0, column=0, padx=(0, 7))
            self._label(line, name, 9, "#BBC1C9", True).grid(row=0, column=1, sticky="w")
            value_label = self._label(line, value, 9, self.MUTED, True)
            value_label.grid(row=0, column=2, sticky="e")
            self.status_value_labels[name] = value_label

        self.left_wave = tk.Canvas(
            status_card, height=42, bg=self.PANEL, highlightthickness=0, bd=0
        )
        self.left_wave.grid(row=6, column=0, sticky="ew", padx=8, pady=(6, 5))

        radar_card = self._panel(self.left_column, "GLOBAL SENSOR GRID", 205)
        radar_card.grid(row=1, column=0, sticky="nsew", pady=(0, 8))
        self.radar_canvas = tk.Canvas(
            radar_card, bg=self.PANEL, highlightthickness=0, bd=0, height=155
        )
        self.radar_canvas.grid(row=1, column=0, sticky="nsew", padx=4, pady=(0, 4))

        core_card = self._panel(self.left_column, "ULTRON CORE", 180)
        core_card.grid(row=2, column=0, sticky="ew")
        self.core_canvas = tk.Canvas(
            core_card, bg=self.PANEL, highlightthickness=0, bd=0, height=137
        )
        self.core_canvas.grid(row=1, column=0, sticky="ew", padx=4, pady=(0, 5))

    def _create_center_column(self):
        self.center_column = ctk.CTkFrame(self.body, fg_color="transparent")
        self.center_column.grid(row=0, column=1, sticky="nsew", padx=7)
        self.center_column.grid_columnconfigure(0, weight=1)
        self.center_column.grid_rowconfigure(0, weight=0)
        self.center_column.grid_rowconfigure(1, weight=1)

        hero_panel = ctk.CTkFrame(
            self.center_column,
            fg_color="#07090D",
            border_width=1,
            border_color="#542312",
            corner_radius=10,
            height=220,
        )
        hero_panel.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        hero_panel.grid_propagate(False)
        self.hero_canvas = tk.Canvas(
            hero_panel, bg="#07090D", highlightthickness=0, bd=0, height=220
        )
        self.hero_canvas.pack(fill="both", expand=True)
        self.hero_canvas.bind("<Configure>", lambda _event: self.draw_hero())

        self.module_host = ctk.CTkFrame(
            self.center_column,
            fg_color=self.PANEL,
            border_width=1,
            border_color=self.LINE,
            corner_radius=10,
        )
        self.module_host.grid(row=1, column=0, sticky="nsew")
        self.module_host.grid_columnconfigure(0, weight=1)
        self.module_host.grid_rowconfigure(1, weight=1)

    def _create_right_column(self):
        self.right_column = ctk.CTkFrame(self.body, fg_color="transparent")
        self.right_column.grid(row=0, column=2, sticky="nsew", padx=(7, 0))
        self.right_column.grid_columnconfigure(0, weight=1)
        self.right_column.grid_rowconfigure(0, weight=1)
        self.right_column.grid_rowconfigure(1, weight=0)

        modules_card = self._panel(self.right_column, "MODULES")
        modules_card.grid(row=0, column=0, sticky="nsew", pady=(0, 8))
        for row, (module, symbol) in enumerate(self.MODULES, start=1):
            btn = ctk.CTkButton(
                modules_card,
                text=f"{symbol}   {module}",
                height=43,
                anchor="w",
                font=("Arial", 10, "bold"),
                text_color="#D9DCE2",
                fg_color="#0C1016",
                hover_color="#25140F",
                border_width=1,
                border_color="#572515",
                corner_radius=7,
                command=lambda name=module: self.show_module(name),
            )
            btn.grid(row=row, column=0, sticky="ew", padx=10, pady=4)
            self.nav_buttons[module] = btn

        emblem_card = self._panel(self.right_column, "ZA17 POWER SIGNATURE", 190)
        emblem_card.grid(row=1, column=0, sticky="ew")
        self.emblem_canvas = tk.Canvas(
            emblem_card, bg=self.PANEL, highlightthickness=0, bd=0, height=145
        )
        self.emblem_canvas.grid(row=1, column=0, sticky="ew", padx=4, pady=(0, 4))

    # ------------------------------------------------------------------
    # CINEMATIC ANIMATION LAYER
    # ------------------------------------------------------------------

    def draw_hero(self):
        if not hasattr(self, "hero_canvas") or not self.hero_canvas.winfo_exists():
            return
        canvas = self.hero_canvas
        canvas.delete("all")
        w = max(canvas.winfo_width(), 380)
        h = max(canvas.winfo_height(), 180)
        cx, cy = w / 2, h / 2 - 2
        frame = self.animation_frame
        color = self.MODE_COLORS.get(self.animation_mode, self.ACCENT)
        radius = min(w * 0.26, h * 0.58, 190)

        # Layered circular machine halo and calibration marks.
        for r, shade, width in [
            (radius + 25, "#32160F", 1),
            (radius + 13, "#6A2815", 2),
            (radius, "#8A351B", 1),
        ]:
            canvas.create_oval(cx-r, cy-r, cx+r, cy+r, outline=shade, width=width)
        for index in range(72):
            angle = math.radians(index * 5 + frame * 0.45)
            inner = radius + (4 if index % 6 == 0 else 9)
            outer = radius + (18 if index % 6 == 0 else 13)
            x1, y1 = cx + math.cos(angle) * inner, cy + math.sin(angle) * inner
            x2, y2 = cx + math.cos(angle) * outer, cy + math.sin(angle) * outer
            canvas.create_line(
                x1, y1, x2, y2,
                fill=color if index % 6 == 0 else "#512115",
                width=2 if index % 6 == 0 else 1,
            )
        start = (frame * 1.25) % 360
        canvas.create_arc(
            cx-radius-10, cy-radius-10, cx+radius+10, cy+radius+10,
            start=start, extent=82, style=tk.ARC, outline=color, width=3,
        )
        canvas.create_arc(
            cx-radius-3, cy-radius-3, cx+radius+3, cy+radius+3,
            start=(start + 190) % 360, extent=40, style=tk.ARC,
            outline=self.ACCENT_HOT, width=2,
        )
        scan_y = (frame * 2.6) % max(h, 1)
        canvas.create_line(8, scan_y, w-8, scan_y, fill="#38180F", width=1)

        # Original ULTRON ZA17 metallic hero artwork; fall back to a vector helmet.
        if self._hero_source is not None:
            max_w = min(int(w * 0.48), 430)
            max_h = int(h * 1.06)
            size_key = (max_w, max_h)
            if self._hero_photo is None or self._hero_photo_size != size_key:
                art = self._hero_source.copy()
                resampling = getattr(Image, "Resampling", Image)
                art.thumbnail(size_key, getattr(resampling, "LANCZOS", Image.LANCZOS))
                self._hero_photo = ImageTk.PhotoImage(art)
                self._hero_photo_size = size_key
            canvas.create_image(cx, cy + 1, image=self._hero_photo, anchor="center")
        else:
            self._draw_vector_helmet(canvas, cx, cy, radius * 0.8)

        # Branding and subtle HUD labels.
        canvas.create_text(
            cx, h - 17, text="ULTRON ZA17",
            fill="#F0E6E2", font=("Arial", 20, "bold"),
        )
        canvas.create_text(
            cx, 15, text="A R T I F I C I A L   I N T E L L I G E N C E   S Y S T E M",
            fill="#C46A43", font=("Arial", 8, "bold"),
        )
        canvas.create_text(16, h - 16, text="CORE // 01", anchor="w", fill="#70402D", font=("Consolas", 8))
        canvas.create_text(w - 16, h - 16, text=self.MODE_LABELS[self.animation_mode], anchor="e", fill=color, font=("Consolas", 8, "bold"))

    def _draw_vector_helmet(self, canvas, cx, cy, radius):
        # Geometric fallback when the artwork file cannot be loaded.
        points = [
            cx, cy-radius,
            cx+radius*.72, cy-radius*.60,
            cx+radius, cy-radius*.03,
            cx+radius*.76, cy+radius*.55,
            cx, cy+radius,
            cx-radius*.76, cy+radius*.55,
            cx-radius, cy-radius*.03,
            cx-radius*.72, cy-radius*.60,
        ]
        canvas.create_polygon(points, fill="#15191F", outline=self.ACCENT, width=3)
        canvas.create_polygon(
            cx-radius*.78, cy-radius*.08, cx-radius*.12, cy-radius*.24,
            cx-radius*.20, cy+radius*.08, cx-radius*.68, cy+radius*.04,
            fill="#FF4F36", outline="#FF9A63", width=2,
        )
        canvas.create_polygon(
            cx+radius*.78, cy-radius*.08, cx+radius*.12, cy-radius*.24,
            cx+radius*.20, cy+radius*.08, cx+radius*.68, cy+radius*.04,
            fill="#FF4F36", outline="#FF9A63", width=2,
        )
        canvas.create_line(cx, cy-radius*.55, cx, cy+radius*.7, fill="#84321D", width=3)

    def draw_radar(self):
        c = self.radar_canvas
        if not c.winfo_exists():
            return
        c.delete("all")
        w, h = max(c.winfo_width(), 180), max(c.winfo_height(), 135)
        cx, cy = w/2, h/2
        r = min(w, h) * .43
        for scale in (1, .72, .44, .16):
            rr = r*scale
            c.create_oval(cx-rr, cy-rr, cx+rr, cy+rr, outline="#5A2818", width=1)
        c.create_line(cx-r, cy, cx+r, cy, fill="#472116")
        c.create_line(cx, cy-r, cx, cy+r, fill="#472116")
        angle = math.radians(self.animation_frame * 2.3 % 360)
        ex, ey = cx + math.cos(angle)*r, cy + math.sin(angle)*r
        c.create_line(cx, cy, ex, ey, fill=self.ACCENT, width=2)
        for idx in range(16):
            a = math.radians(idx*22.5 + self.animation_frame*.45)
            px, py = cx+math.cos(a)*r*.82, cy+math.sin(a)*r*.82
            size = 2 if idx % 4 else 3
            c.create_oval(px-size, py-size, px+size, py+size, fill="#F16A3B" if idx % 4 == 0 else "#69301F", outline="")
        c.create_text(cx, h-7, text="LOCAL GRID // VISUAL", fill="#81513B", font=("Consolas", 7))

    def draw_core(self):
        c = self.core_canvas
        if not c.winfo_exists():
            return
        c.delete("all")
        w, h = max(c.winfo_width(), 180), max(c.winfo_height(), 120)
        cx, cy = w/2, h/2-2
        r = min(w*.31, h*.44)
        pulse = 2.5*math.sin(self.animation_frame*.08)
        for scale, col in ((1.0, "#652719"), (.78, "#8B351D"), (.55, "#32170F")):
            rr = r*scale
            c.create_oval(cx-rr, cy-rr, cx+rr, cy+rr, outline=col, width=2)
        c.create_arc(cx-r, cy-r, cx+r, cy+r, start=(self.animation_frame*2)%360, extent=250, style=tk.ARC, outline=self.ACCENT_HOT, width=5)
        c.create_oval(cx-14-pulse, cy-14-pulse, cx+14+pulse, cy+14+pulse, fill="#9E321C", outline="#FFB07B", width=2)
        c.create_text(cx, cy+r+16, text="CORE READY", fill="#F0B18C", font=("Arial", 9, "bold"))

    def draw_emblem(self):
        c = self.emblem_canvas
        if not c.winfo_exists():
            return
        c.delete("all")
        w, h = max(c.winfo_width(), 180), max(c.winfo_height(), 130)
        cx, cy = w/2, h/2-3
        r = min(w*.32, h*.46)
        for n in range(4):
            rr = r*(1+n*.18)
            c.create_oval(cx-rr, cy-rr, cx+rr, cy+rr, outline="#5B2718" if n else self.ACCENT, width=2 if n==0 else 1)
        for i in range(16):
            a = math.radians(i*22.5-self.animation_frame*.8)
            x1, y1 = cx+math.cos(a)*r*.9, cy+math.sin(a)*r*.9
            x2, y2 = cx+math.cos(a)*r*1.15, cy+math.sin(a)*r*1.15
            c.create_line(x1,y1,x2,y2,fill=self.ACCENT_HOT if i%4==0 else "#63301E",width=2 if i%4==0 else 1)
        c.create_text(cx, cy, text="ZA17", fill="#EDE5E0", font=("Arial", 19, "bold"))

    def draw_wave(self, canvas, mode_factor=1.0):
        if not canvas.winfo_exists():
            return
        canvas.delete("all")
        w, h = max(canvas.winfo_width(), 100), max(canvas.winfo_height(), 25)
        count = 42 if w > 280 else 30
        gap = max(w-16, 80)/count
        mode = self.animation_mode
        for i in range(count):
            wave = abs(math.sin(self.animation_frame*.16+i*.53) + .32*math.sin(self.animation_frame*.08-i*.19))
            if mode == "IDLE":
                amp = 3 + wave*4
            elif mode == "LISTENING":
                amp = 4 + wave*(h*.45)
            elif mode == "THINKING":
                amp = 4 + abs(math.sin(self.animation_frame*.24+i*.21))*(h*.42)
            elif mode == "SPEAKING":
                amp = 4 + wave*(h*.40)
            else:
                amp = 4 + wave*(h*.30)
            x = 8 + (i+.5)*gap
            c = self.ACCENT_HOT if i%5 == 0 else "#9D3F22"
            canvas.create_line(x, h/2-amp/2, x, h/2+amp/2, fill=c, width=2)

    def animate_interface(self):
        if self._closing:
            return
        self.animation_frame += 1
        self.draw_hero()
        self.draw_radar()
        self.draw_core()
        self.draw_emblem()
        self.draw_wave(self.left_wave)
        self.draw_wave(self.footer_wave)
        if self.active_module == "VOICE CONTROL" and hasattr(self, "voice_ring_canvas"):
            self.draw_voice_ring()
        self.after(40, self.animate_interface)

    def set_animation_mode(self, mode):
        if mode not in self.MODE_COLORS:
            mode = "IDLE"
        self.animation_mode = mode
        if hasattr(self, "top_mode") and self.top_mode.winfo_exists():
            self.top_mode.configure(
                text=f"● {self.MODE_LABELS[mode]}",
                text_color=self.MODE_COLORS[mode],
            )

    # ------------------------------------------------------------------
    # MODULE NAVIGATION
    # ------------------------------------------------------------------

    def show_module(self, module):
        self.active_module = module
        for name, button in self.nav_buttons.items():
            button.configure(
                fg_color="#35160F" if name == module else "#0C1016",
                border_color=self.ACCENT if name == module else "#572515",
                text_color=self.ACCENT_HOT if name == module else "#D9DCE2",
            )
        self._clear_host()
        if module == "CHAT AI":
            self._render_chat_page(False)
        elif module == "CODE ASSIST":
            self._render_chat_page(True)
        elif module == "ROBOT CONTROL":
            self._render_robot_page()
        elif module == "VOICE CONTROL":
            self._render_voice_page()
        elif module == "SYSTEM TOOLS":
            self._render_system_tools_page()
        elif module == "HOME CONTROL":
            self._render_home_page()
        else:
            self._render_more_page()

    # ------------------------------------------------------------------
    # CHAT AND CODE ASSIST
    # ------------------------------------------------------------------

    def _render_chat_page(self, code_mode=False):
        host = self.module_host
        host.grid_rowconfigure(1, weight=1)
        self._page_heading(
            host,
            "CODE ASSIST" if code_mode else "AI COMMUNICATION CONSOLE",
            "LOCAL QWEN MODEL  /  CONVERSATION LINK",
        )
        self.chat = ctk.CTkTextbox(
            host,
            font=("Consolas", 12),
            fg_color="#07090D",
            text_color=self.TEXT,
            border_width=1,
            border_color="#382016",
            corner_radius=8,
            wrap="word",
        )
        self.chat.grid(row=1, column=0, sticky="nsew", padx=14, pady=(3, 8))
        if not self.chat_history:
            self.chat_history.append(("ULTRON", "System online. All systems are ready. Awaiting your command."))
        for speaker, message in self.chat_history[-80:]:
            self.chat.insert("end", f"{speaker}: {message}\n\n")
        self.chat.see("end")

        input_row = ctk.CTkFrame(host, fg_color="transparent")
        input_row.grid(row=2, column=0, sticky="ew", padx=14, pady=(0, 7))
        input_row.grid_columnconfigure(0, weight=1)
        self.entry = ctk.CTkEntry(
            input_row,
            height=43,
            placeholder_text="Ask ULTRON for code help..." if code_mode else "Enter your command...",
            font=("Arial", 13),
            fg_color="#10141A",
            border_color="#743018",
            text_color=self.TEXT,
        )
        self.entry.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        self.entry.bind("<Return>", lambda _event: self.send_message())
        self.send_button = ctk.CTkButton(
            input_row,
            text="TRANSMIT  ➤",
            width=132,
            height=43,
            font=("Arial", 11, "bold"),
            fg_color="#922E19",
            hover_color="#C74B25",
            command=self.send_message,
        )
        self.send_button.grid(row=0, column=1, padx=(0, 8))
        self.mic_button = ctk.CTkButton(
            input_row,
            text="MIC ON" if self.mic_enabled else "VOICE",
            width=95,
            height=43,
            font=("Arial", 11, "bold"),
            fg_color="#29140F",
            hover_color="#78321C",
            command=self.toggle_microphone,
        )
        self.mic_button.grid(row=0, column=2)
        self._code_mode = code_mode

    def _append_chat_history(self, speaker, message):
        self.chat_history.append((speaker, str(message)))
        if len(self.chat_history) > 100:
            self.chat_history = self.chat_history[-100:]
        if self.chat is not None and self.chat.winfo_exists():
            self.chat.insert("end", f"{speaker}: {message}\n\n")
            self.chat.see("end")

    def send_message(self):
        if self._busy or self.entry is None or not self.entry.winfo_exists():
            return
        message = self.entry.get().strip()
        if not message:
            return
        self.entry.delete(0, "end")
        code_mode = self.active_module == "CODE ASSIST"
        self._append_chat_history("YOU", message)
        self.set_animation_mode("THINKING")
        self._busy = True
        if self.send_button and self.send_button.winfo_exists():
            self.send_button.configure(state="disabled", text="PROCESSING...")
        threading.Thread(
            target=self._process_user_message,
            args=(message, code_mode),
            daemon=True,
        ).start()

    def _process_user_message(self, message, code_mode=False):
        response = None
        direct_action = False
        try:
            # Route explicitly recognised home-appliance commands through the
            # dedicated controller before the general system operator or AI.
            if not code_mode and self.home_controller:
                response = self.home_controller.execute_natural_language(message)
                direct_action = response is not None
            if response is None and not code_mode and self.system_operator:
                response = self.system_operator.execute(message)
                direct_action = response is not None
            if response is None:
                if not self.ai:
                    response = "AI engine is unavailable. Check core/ai_engine.py and the Ollama installation."
                else:
                    prompt = message
                    if code_mode:
                        prompt = "Act as a clear, careful programming assistant. Explain code step by step when useful. User request: " + message
                    response = self.ai.get_response(prompt)
        except Exception as error:
            response = f"ULTRON SYSTEM ERROR: {error}"
        self.after(0, lambda r=response, d=direct_action: self._finish_user_message(r, d))

    def _finish_user_message(self, response, direct_action=False):
        if self._closing:
            return
        self._busy = False
        if self.send_button is not None and self.send_button.winfo_exists():
            self.send_button.configure(state="normal", text="TRANSMIT  ➤")
        self._append_chat_history("ULTRON", response)
        if "SYSTEM ERROR" in str(response) or "error:" in str(response).lower():
            self.set_animation_mode("ERROR")
        else:
            self.speak_response(response)

    def speak_response(self, response):
        if not self.voice:
            self.set_animation_mode("IDLE")
            return
        self.set_animation_mode("SPEAKING")
        try:
            self.voice.speak(str(response))
        except Exception as error:
            self.set_animation_mode("ERROR")
            self._append_chat_history("SYSTEM", f"Voice output error: {error}")
            return
        if not self._speech_monitor_running:
            self._speech_monitor_running = True
            self.after(300, self.check_speech_status)

    def check_speech_status(self):
        if self._closing:
            return
        pending = False
        try:
            pending = (not self.voice.tasks.empty()) or bool(self.voice.speaking)
        except Exception:
            pending = bool(getattr(self.voice, "speaking", False))
        if pending:
            self.after(300, self.check_speech_status)
        else:
            self._speech_monitor_running = False
            self.set_animation_mode("LISTENING" if self.mic_enabled else "IDLE")

    # ------------------------------------------------------------------
    # ROBOT CONTROL
    # ------------------------------------------------------------------

    def _render_robot_page(self):
        host = self.module_host
        host.grid_rowconfigure(1, weight=1)
        self._page_heading(host, "ROBOT CONTROL", "MANUAL REMOTE  /  SOFTWARE CONTROLLER")

        content = ctk.CTkFrame(host, fg_color="transparent")
        content.grid(row=1, column=0, sticky="nsew", padx=16, pady=(4, 14))
        content.grid_columnconfigure(0, weight=1)
        content.grid_columnconfigure(1, weight=1)
        content.grid_rowconfigure(0, weight=1)

        remote_card = ctk.CTkFrame(content, fg_color="#0B0E13", border_width=1, border_color="#5B2518", corner_radius=10)
        remote_card.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        self._label(remote_card, "DIRECTIONAL CONTROL", 11, self.ACCENT_HOT, True).pack(pady=(16, 12))
        pad = ctk.CTkFrame(remote_card, fg_color="transparent")
        pad.pack(expand=True)
        self._robot_button(pad, "▲\nFORWARD", "FORWARD", 0, 1)
        self._robot_button(pad, "◀\nLEFT", "LEFT", 1, 0)
        self._robot_button(pad, "■\nSTOP", "STOP", 1, 1, stop=True)
        self._robot_button(pad, "RIGHT\n▶", "RIGHT", 1, 2)
        self._robot_button(pad, "▼\nBACKWARD", "BACKWARD", 2, 1)
        self._label(remote_card, "KEYBOARD: W / A / S / D  •  SPACE = STOP", 9, self.MUTED).pack(pady=(4, 13))

        info = ctk.CTkFrame(content, fg_color="#0B0E13", border_width=1, border_color="#3E241B", corner_radius=10)
        info.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        self._label(info, "HARDWARE LINK", 11, self.ACCENT_HOT, True).pack(anchor="w", padx=16, pady=(16, 8))
        connected = bool(getattr(self.robot, "connected", False))
        status = "CONNECTED" if connected else "NOT CONNECTED"
        self._label(info, f"●  {status}", 17, self.GREEN if connected else self.RED, True).pack(anchor="w", padx=16, pady=6)
        self._label(info, "Controller: Arduino interface not configured", 10, self.MUTED).pack(anchor="w", padx=16, pady=4)
        self._label(info, "Motor driver: L298N integration pending", 10, self.MUTED).pack(anchor="w", padx=16, pady=4)
        self._label(info, "Sensors: HC-SR04 / servo integration pending", 10, self.MUTED).pack(anchor="w", padx=16, pady=4)
        note = ctk.CTkLabel(
            info,
            text="TEST MODE ONLY\nCommands are stored locally by the current controller stub.\nThe physical car will not move until serial hardware\ncommunication is added and tested.",
            justify="left",
            wraplength=310,
            font=("Arial", 10, "bold"),
            text_color="#E3A17D",
        )
        note.pack(anchor="w", padx=16, pady=(16, 10))
        self.robot_page_status = self._label(info, "Last command: STOP", 10, self.ACCENT_HOT, True)
        self.robot_page_status.pack(anchor="w", padx=16, pady=(3, 14))

    def _robot_button(self, parent, label, command, row, column, stop=False):
        button = ctk.CTkButton(
            parent,
            text=label,
            width=106,
            height=58,
            font=("Arial", 10, "bold"),
            fg_color="#8C2819" if stop else "#171B22",
            hover_color="#BD3E23" if stop else "#303844",
            border_width=1,
            border_color="#A34125" if stop else "#69301E",
            corner_radius=8,
            command=lambda c=command: self.send_robot_command(c),
        )
        button.grid(row=row, column=column, padx=5, pady=5)

    def send_robot_command(self, command):
        if not self.robot:
            result = "Robot controller module is unavailable."
        elif command == "STOP":
            result = self.robot.emergency_stop()
        else:
            result = self.robot.send_command(command)
        if not getattr(self.robot, "connected", False):
            result = f"TEST MODE — HARDWARE NOT CONNECTED. {result}"
        self.set_animation_mode("EXECUTING")
        self.footer_right.configure(text=f"ROBOT: {command}  /  NOT CONNECTED", text_color=self.RED)
        if hasattr(self, "robot_page_status") and self.robot_page_status.winfo_exists():
            self.robot_page_status.configure(text=f"Last command: {command}  •  {result}")
        if self.active_module == "ROBOT CONTROL":
            self._append_chat_history("ROBOT", result)

    def handle_keypress(self, event):
        if self.active_module != "ROBOT CONTROL":
            return
        widget_class = event.widget.winfo_class()
        if widget_class in ("Entry", "Text") or "Entry" in widget_class or "Text" in widget_class:
            return
        commands = {"w": "FORWARD", "s": "BACKWARD", "a": "LEFT", "d": "RIGHT"}
        key = event.keysym.lower()
        if key in commands:
            self.send_robot_command(commands[key])
        elif key == "space":
            self.send_robot_command("STOP")

    # ------------------------------------------------------------------
    # VOICE CONTROL
    # ------------------------------------------------------------------

    def _render_voice_page(self):
        host = self.module_host
        host.grid_rowconfigure(1, weight=1)
        self._page_heading(host, "VOICE CONTROL", "MICROPHONE INPUT  /  SPEECH OUTPUT")
        area = ctk.CTkFrame(host, fg_color="transparent")
        area.grid(row=1, column=0, sticky="nsew", padx=18, pady=10)
        area.grid_columnconfigure(0, weight=1)
        area.grid_rowconfigure(0, weight=1)
        card = ctk.CTkFrame(area, fg_color="#0A0E13", border_width=1, border_color="#542615", corner_radius=10)
        card.grid(row=0, column=0, sticky="nsew")
        self.voice_state_label = self._label(
            card,
            "MICROPHONE ACTIVE" if self.mic_enabled else "MICROPHONE STANDBY",
            20,
            self.ACCENT_HOT,
            True,
        )
        self.voice_state_label.pack(pady=(34, 14))
        voice_ring = tk.Canvas(card, width=230, height=170, bg="#0A0E13", highlightthickness=0)
        voice_ring.pack(pady=2)
        self.voice_ring_canvas = voice_ring
        self.voice_page_button = ctk.CTkButton(
            card,
            text="TURN MICROPHONE OFF" if self.mic_enabled else "ACTIVATE MICROPHONE",
            width=260,
            height=46,
            fg_color="#922E19",
            hover_color="#C74B25",
            font=("Arial", 11, "bold"),
            command=self.toggle_microphone,
        )
        self.voice_page_button.pack(pady=12)
        self._label(
            card,
            "Speech recognition uses the online en-IN recognition service.\nKeep the microphone enabled only while you want ULTRON to listen.",
            10,
            self.MUTED,
            justify="center",
        ).pack(pady=(4, 22))
        self.draw_voice_ring()

    def draw_voice_ring(self):
        canvas = getattr(self, "voice_ring_canvas", None)
        if canvas is None or not canvas.winfo_exists():
            return
        canvas.delete("all")
        cx, cy = 115, 83
        pulse = 4*math.sin(self.animation_frame*.1)
        for r in (40, 54, 68):
            canvas.create_oval(cx-r-pulse, cy-r-pulse, cx+r+pulse, cy+r+pulse, outline="#7B2D19", width=2)
        canvas.create_oval(cx-29, cy-29, cx+29, cy+29, fill="#35150D", outline=self.ACCENT_HOT, width=3)
        canvas.create_text(cx, cy, text="MIC", fill=self.TEXT, font=("Arial", 11, "bold"))
        for i in range(30):
            wave = abs(math.sin(self.animation_frame * .17 + i * .48))
            bar_h = 3 + wave * 17 if self.mic_enabled else 3 + wave * 4
            x = 18 + i * 6.8
            canvas.create_line(x, 151 - bar_h/2, x, 151 + bar_h/2,
                               fill=self.ACCENT_HOT if i % 5 == 0 else "#8D3A20", width=2)

    def toggle_microphone(self):
        if not self.mic_enabled:
            if sr is None:
                self._append_chat_history("SYSTEM", "SpeechRecognition is not installed. Install it before enabling the microphone.")
                self.set_animation_mode("ERROR")
                return
            self.mic_enabled = True
            self.set_animation_mode("LISTENING")
            self.set_status("MIC INPUT", "LISTENING", self.ACCENT_HOT)
            self.footer_status.configure(text="MICROPHONE ACTIVE  //  EN-IN SPEECH RECOGNITION")
            self.listen_thread = threading.Thread(target=self.listen_continuously, daemon=True)
            self.listen_thread.start()
        else:
            self.mic_enabled = False
            self.set_animation_mode("IDLE")
            self.set_status("MIC INPUT", "OFF", self.MUTED)
            self.footer_status.configure(text="ULTRON ZA17  //  LOCAL COMMAND CENTER")
        if self.mic_button and self.mic_button.winfo_exists():
            self.mic_button.configure(text="MIC ON" if self.mic_enabled else "VOICE")
        if hasattr(self, "voice_page_button") and self.voice_page_button.winfo_exists():
            self.voice_page_button.configure(text="TURN MICROPHONE OFF" if self.mic_enabled else "ACTIVATE MICROPHONE")
        if hasattr(self, "voice_state_label") and self.voice_state_label.winfo_exists():
            self.voice_state_label.configure(text="MICROPHONE ACTIVE" if self.mic_enabled else "MICROPHONE STANDBY")

    def listen_continuously(self):
        recognizer = sr.Recognizer()
        recognizer.dynamic_energy_threshold = True
        try:
            with sr.Microphone() as source:
                recognizer.adjust_for_ambient_noise(source, duration=0.45)
                while self.mic_enabled and not self._closing:
                    try:
                        audio = recognizer.listen(source, timeout=1, phrase_time_limit=6)
                        message = recognizer.recognize_google(audio, language="en-IN").strip()
                        if not message:
                            continue
                        self.after(0, lambda m=message: self.process_voice_message(m))
                    except sr.WaitTimeoutError:
                        continue
                    except sr.UnknownValueError:
                        continue
                    except sr.RequestError as error:
                        self.after(0, lambda e=error: self.show_mic_error(e))
                        time.sleep(2)
        except Exception as error:
            self.after(0, lambda e=error: self.show_mic_error(e))

    def process_voice_message(self, message):
        if not self.mic_enabled or self._closing:
            return
        robot_command = self._detect_robot_voice_command(message)
        if robot_command:
            self.show_module("ROBOT CONTROL")
            self.send_robot_command(robot_command)
            return
        self.show_module("CHAT AI")
        if self.entry and self.entry.winfo_exists():
            self.entry.delete(0, "end")
            self.entry.insert(0, message)
            self.send_message()

    @staticmethod
    def _detect_robot_voice_command(message):
        text = message.lower().strip()
        patterns = {
            "STOP": (r"\b(robot\s+)?stop\b", r"\bemergency stop\b", r"\bstop the robot\b"),
            "FORWARD": (r"\b(move|go|drive|robot) forward\b",),
            "BACKWARD": (r"\b(move|go|drive|robot) backward\b", r"\b(reverse|back up)\b"),
            "LEFT": (r"\b(turn|move|drive|robot) left\b",),
            "RIGHT": (r"\b(turn|move|drive|robot) right\b",),
        }
        for command, expressions in patterns.items():
            if any(re.search(pattern, text) for pattern in expressions):
                return command
        return None

    def show_mic_error(self, error):
        self.mic_enabled = False
        self.set_status("MIC INPUT", "ERROR", self.RED)
        self.set_animation_mode("ERROR")
        if self.mic_button and self.mic_button.winfo_exists():
            self.mic_button.configure(text="VOICE")
        if hasattr(self, "voice_page_button") and self.voice_page_button.winfo_exists():
            self.voice_page_button.configure(text="ACTIVATE MICROPHONE")
        if hasattr(self, "voice_state_label") and self.voice_state_label.winfo_exists():
            self.voice_state_label.configure(text="MICROPHONE ERROR")
        self._append_chat_history("SYSTEM", f"Microphone error: {error}")

    # ------------------------------------------------------------------
    # SYSTEM TOOLS, HOME CONTROL, AND DIAGNOSTICS
    # ------------------------------------------------------------------

    def _render_system_tools_page(self):
        host = self.module_host
        host.grid_rowconfigure(1, weight=1)
        self._page_heading(host, "SYSTEM TOOLS", "ALLOWLISTED WINDOWS APPLICATIONS AND WEB SEARCH")
        area = ctk.CTkFrame(host, fg_color="transparent")
        area.grid(row=1, column=0, sticky="nsew", padx=16, pady=(4, 12))
        area.grid_columnconfigure((0, 1), weight=1)
        for index, app in enumerate(("Chrome", "Notepad", "Calculator", "File Explorer", "VS Code")):
            r, col = divmod(index, 2)
            ctk.CTkButton(
                area,
                text=f"OPEN  {app.upper()}",
                height=42,
                font=("Arial", 10, "bold"),
                fg_color="#171B22",
                hover_color="#4A2418",
                border_width=1,
                border_color="#63301E",
                command=lambda name=app: self.open_app(name),
            ).grid(row=r, column=col, sticky="ew", padx=6, pady=6)
        search = ctk.CTkFrame(area, fg_color="#0A0E13", corner_radius=8)
        search.grid(row=3, column=0, columnspan=2, sticky="ew", padx=6, pady=(18, 4))
        search.grid_columnconfigure(0, weight=1)
        self.tool_search_entry = ctk.CTkEntry(search, height=42, placeholder_text="Search Google for...", fg_color="#111720", border_color="#63301E")
        self.tool_search_entry.grid(row=0, column=0, sticky="ew", padx=8, pady=8)
        ctk.CTkButton(search, text="SEARCH", width=100, command=self.run_tool_search, fg_color="#8F2E19", hover_color="#C64A24").grid(row=0, column=1, padx=8, pady=8)
        self.tool_status = self._label(area, "Only the existing allowlisted system actions are available.", 9, self.MUTED)
        self.tool_status.grid(row=4, column=0, columnspan=2, sticky="w", padx=8, pady=12)

    def open_app(self, app):
        if not self.system_operator:
            result = "System Operator module is unavailable."
        else:
            mapping = {"Chrome": "chrome", "Notepad": "notepad", "Calculator": "calculator", "File Explorer": "file explorer", "VS Code": "vscode"}
            result = self.system_operator.open_app(mapping[app])
        if hasattr(self, "tool_status") and self.tool_status.winfo_exists():
            self.tool_status.configure(text=result or f"Could not open {app}.")

    def run_tool_search(self):
        query = self.tool_search_entry.get().strip() if hasattr(self, "tool_search_entry") else ""
        if not query:
            return
        result = self.system_operator.execute(f"search Google for {query}") if self.system_operator else "System Operator is unavailable."
        if self.tool_status and self.tool_status.winfo_exists():
            self.tool_status.configure(text=result or "Search command was not recognized.")

    def _render_home_page(self):
        host = self.module_host
        host.grid_rowconfigure(1, weight=1)
        self._page_heading(
            host,
            "HOME CONTROL",
            "LIGHTS / TV / FAN  •  SAFE SIMULATION MODE",
        )
        area = ctk.CTkFrame(host, fg_color="transparent")
        area.grid(row=1, column=0, sticky="nsew", padx=14, pady=(5, 12))
        area.grid_columnconfigure((0, 1), weight=1)

        if not self.home_controller:
            self._label(
                area,
                f"HOME CONTROLLER UNAVAILABLE: {HOME_IMPORT_ERROR}",
                10,
                self.RED,
                True,
                wraplength=390,
            ).grid(row=0, column=0, columnspan=2, sticky="w", padx=6, pady=12)
            return

        banner = ctk.CTkFrame(
            area, fg_color="#24150F", border_width=1,
            border_color="#A34A25", corner_radius=8,
        )
        banner.grid(row=0, column=0, columnspan=2, sticky="ew", padx=4, pady=(0, 9))
        self._label(
            banner, "●  DEMO MODE  /  NO PHYSICAL APPLIANCE IS CONNECTED",
            9, "#FFB17C", True,
        ).pack(anchor="w", padx=11, pady=9)

        self.home_state_labels = {}
        self.home_power_buttons = {}

        cards = [
            ("LIGHTS", "💡", 1, 0),
            ("TELEVISION", "▣", 1, 1),
            ("FAN", "✥", 2, 0),
        ]
        for device, icon, row, col in cards:
            span = 2 if device == "FAN" else 1
            card = ctk.CTkFrame(
                area, fg_color="#0A0E13", border_width=1,
                border_color="#512719", corner_radius=9,
            )
            card.grid(
                row=row, column=col, columnspan=span, sticky="ew",
                padx=4, pady=5,
            )
            if device == "FAN":
                card.grid_columnconfigure(0, weight=1)
            self._label(card, f"{icon}  {device}", 12, self.ACCENT_HOT, True).pack(
                anchor="w", padx=12, pady=(11, 5)
            )
            state = self.home_controller.get_device_status(device)
            state_label = self._label(
                card,
                "SIMULATED ON" if state["is_on"] else "OFF  /  SIMULATED",
                10, self.GREEN if state["is_on"] else self.MUTED, True,
            )
            state_label.pack(anchor="w", padx=12, pady=3)
            self.home_state_labels[device] = state_label
            button = ctk.CTkButton(
                card,
                text="TURN OFF" if state["is_on"] else "TURN ON",
                height=34,
                width=112,
                font=("Arial", 10, "bold"),
                fg_color="#762B1B" if state["is_on"] else "#183021",
                hover_color="#A94325" if state["is_on"] else "#28523B",
                border_width=1,
                border_color="#A34A25" if state["is_on"] else "#367B4E",
                command=lambda d=device: self.toggle_home_device(d),
            )
            button.pack(anchor="w", padx=12, pady=(5, 11))
            self.home_power_buttons[device] = button

            if device == "FAN":
                speed_row = ctk.CTkFrame(card, fg_color="transparent")
                speed_row.pack(fill="x", padx=10, pady=(0, 10))
                self._label(speed_row, "SPEED", 9, self.MUTED, True).pack(
                    side="left", padx=(2, 8)
                )
                self.home_fan_speed_label = self._label(
                    speed_row, f"{state['speed']}/5", 9, self.ACCENT_HOT, True
                )
                self.home_fan_speed_label.pack(side="right", padx=5)
                for speed in range(1, 6):
                    ctk.CTkButton(
                        speed_row, text=str(speed), width=28, height=27,
                        font=("Arial", 9, "bold"),
                        fg_color="#272019", hover_color="#71331E",
                        command=lambda value=speed: self.set_home_fan_speed(value),
                    ).pack(side="left", padx=2)

        examples = self._label(
            area,
            "VOICE / CHAT COMMANDS:  'Turn on the lights'  •  'Turn off the TV'  •  'Set fan speed to 3'",
            9, "#CBA48D", wraplength=390, justify="left",
        )
        examples.grid(row=3, column=0, columnspan=2, sticky="ew", padx=7, pady=(8, 4))
        self.home_feedback_label = self._label(
            area,
            "Ready. Actions on this page change demo states only.",
            9, self.MUTED, wraplength=390, justify="left",
        )
        self.home_feedback_label.grid(
            row=4, column=0, columnspan=2, sticky="ew", padx=7, pady=(2, 6)
        )

    def _refresh_home_controls(self, message=None):
        if not self.home_controller:
            return
        for device, label in getattr(self, "home_state_labels", {}).items():
            state = self.home_controller.get_device_status(device)
            label.configure(
                text="SIMULATED ON" if state["is_on"] else "OFF  /  SIMULATED",
                text_color=self.GREEN if state["is_on"] else self.MUTED,
            )
            button = self.home_power_buttons.get(device)
            if button and button.winfo_exists():
                button.configure(
                    text="TURN OFF" if state["is_on"] else "TURN ON",
                    fg_color="#762B1B" if state["is_on"] else "#183021",
                )
        fan_state = self.home_controller.get_device_status("FAN")
        if hasattr(self, "home_fan_speed_label") and self.home_fan_speed_label.winfo_exists():
            self.home_fan_speed_label.configure(text=f"{fan_state['speed']}/5")
        if message and hasattr(self, "home_feedback_label") and self.home_feedback_label.winfo_exists():
            self.home_feedback_label.configure(text=message, text_color=self.ACCENT_HOT)

    def toggle_home_device(self, device):
        if not self.home_controller:
            return
        result = self.home_controller.toggle_device(device)
        self._refresh_home_controls(result)
        self.set_animation_mode("EXECUTING")

    def set_home_fan_speed(self, speed):
        if not self.home_controller:
            return
        result = self.home_controller.set_fan_speed(speed)
        self._refresh_home_controls(result)
        self.set_animation_mode("EXECUTING")

    def _render_more_page(self):
        host = self.module_host
        host.grid_rowconfigure(1, weight=1)
        self._page_heading(host, "SYSTEM DIAGNOSTICS", "MODULE AVAILABILITY  /  IMPLEMENTATION STATUS")
        area = ctk.CTkFrame(host, fg_color="transparent")
        area.grid(row=1, column=0, sticky="nsew", padx=18, pady=10)
        area.grid_columnconfigure(0, weight=1)
        checks = [
            ("AI ENGINE", "Initialized" if self.ai else f"Unavailable: {AI_IMPORT_ERROR}"),
            ("VOICE OUTPUT", "Loaded" if self.voice else f"Unavailable: {VOICE_IMPORT_ERROR}"),
            ("SYSTEM OPERATOR", "Loaded" if self.system_operator else f"Unavailable: {SYSTEM_IMPORT_ERROR}"),
            ("ROBOT CONTROLLER", "Software controller loaded; physical serial link pending" if self.robot else f"Unavailable: {ROBOT_IMPORT_ERROR}"),
            ("MICROPHONE", "SpeechRecognition available" if sr else "SpeechRecognition package unavailable"),
            ("HOME AUTOMATION", "Simulation ready; physical controller not connected" if self.home_controller else f"Unavailable: {HOME_IMPORT_ERROR}"),
        ]
        for idx, (name, value) in enumerate(checks):
            line = ctk.CTkFrame(area, fg_color="#0A0E13", corner_radius=7)
            line.grid(row=idx, column=0, sticky="ew", pady=4)
            line.grid_columnconfigure(1, weight=1)
            self._label(line, name, 10, self.ACCENT_HOT, True).grid(row=0, column=0, sticky="w", padx=12, pady=10)
            self._label(line, value, 9, self.TEXT).grid(row=0, column=1, sticky="e", padx=12, pady=10)

    # ------------------------------------------------------------------
    # SHUTDOWN
    # ------------------------------------------------------------------

    def on_close(self):
        self._closing = True
        self.mic_enabled = False
        try:
            if self.voice:
                self.voice.stop()
        except Exception:
            pass
        self.destroy()


if __name__ == "__main__":
    app = UltronApp()
    app.mainloop()
