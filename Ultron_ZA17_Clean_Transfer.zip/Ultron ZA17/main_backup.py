import tkinter as tk
import math
import threading
import speech_recognition as sr
import customtkinter as ctk

from core.ai_engine import UltronAI
from core.voice_engine import UltronVoice
from modules.robot_controller import RobotController
from modules.system_operator import SystemOperator

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")


class UltronApp(ctk.CTk):

    def __init__(self):
        super().__init__()

        self.system_operator = SystemOperator()
        self.ai = UltronAI()
        self.robot = RobotController()
        self.voice = UltronVoice()

        self.mic_enabled = False
        self.listen_thread = None
        self.mic_lock = threading.Lock()

        self.title("ULTRON ZA17")
        self.geometry("1100x700")
        self.configure(fg_color="#080B16")

        self.create_interface()

        self.bind("<KeyPress>", self.handle_keypress)
        self.focus_set()

    # --------------------------------
    # MAIN INTERFACE
    # --------------------------------

    def create_interface(self):

        title = ctk.CTkLabel(
            self,
            text="ULTRON ZA17",
            font=("Arial", 32, "bold"),
            text_color="#FF6A00"
        )
        title.pack(pady=20)

        subtitle = ctk.CTkLabel(
            self,
            text="ARTIFICIAL INTELLIGENCE SYSTEM",
            font=("Arial", 13),
            text_color="#FF9A3D"
        )
        subtitle.pack()

        self.reactor = tk.Canvas(
            self,
            width=1200,
            height=170,
            bg="#080808",
            highlightthickness=0
        )
        self.reactor.pack(fill="x", padx=20, pady=10)

        self.reactor_frame = 0
        self.animate_reactor()

        self.chat = ctk.CTkTextbox(
            self,
            width=950,
            height=280,
            font=("Consolas", 15),
            fg_color="#101827",
            text_color="#FF6A00"
        )
        self.chat.pack(padx=20, pady=20)

        self.chat.insert(
            "end",
            "ULTRON: System online. All systems operational.\n\n"
        )

        self.entry = ctk.CTkEntry(
            self,
            width=700,
            height=45,
            placeholder_text="Enter your command..."
        )
        self.entry.pack(pady=10)

        self.entry.bind(
            "<Return>",
            lambda event: self.send_message()
        )

        buttons = ctk.CTkFrame(
            self,
            fg_color="transparent"
        )
        buttons.pack(pady=10)

        ctk.CTkButton(
            buttons,
            text="SEND",
            command=self.send_message,
            width=150,
            fg_color="#D95B00",
            hover_color="#FF8C1A"
        ).pack(side="left", padx=10)

        self.mic_button = ctk.CTkButton(
            buttons,
            text="MIC OFF",
            command=self.toggle_microphone,
            width=150,
            fg_color="#8B0000",
            hover_color="#FF4500"
        )
        self.mic_button.pack(side="left", padx=10)

        self.status = ctk.CTkLabel(
            self,
            text="● SYSTEM ONLINE",
            text_color="#00FF88"
        )
        self.status.pack(pady=10)

        # ROBOT CONTROL PANEL

        self.robot_frame = ctk.CTkFrame(
            self,
            fg_color="#181818",
            corner_radius=15
        )
        self.robot_frame.pack(pady=10)

        robot_title = ctk.CTkLabel(
            self.robot_frame,
            text="ULTRON ROBOT CONTROL",
            font=("Arial", 18, "bold"),
            text_color="#FF6A00"
        )
        robot_title.pack(pady=10)

        self.robot_status = ctk.CTkLabel(
            self.robot_frame,
            text="CONTROLLER READY",
            text_color="#00FF88"
        )
        self.robot_status.pack(pady=5)

        self.remote_frame = ctk.CTkFrame(
            self.robot_frame,
            fg_color="transparent"
        )
        self.remote_frame.pack(pady=10)

        ctk.CTkButton(
            self.remote_frame,
            text="▲ FORWARD",
            width=130,
            fg_color="#D95B00",
            command=lambda: self.robot.send_command("FORWARD")
        ).grid(row=0, column=1, padx=5, pady=5)

        ctk.CTkButton(
            self.remote_frame,
            text="◀ LEFT",
            width=130,
            fg_color="#D95B00",
            command=lambda: self.robot.send_command("LEFT")
        ).grid(row=1, column=0, padx=5, pady=5)

        ctk.CTkButton(
            self.remote_frame,
            text="■ STOP",
            width=130,
            fg_color="#B00000",
            command=self.robot.emergency_stop
        ).grid(row=1, column=1, padx=5, pady=5)

        ctk.CTkButton(
            self.remote_frame,
            text="RIGHT ▶",
            width=130,
            fg_color="#D95B00",
            command=lambda: self.robot.send_command("RIGHT")
        ).grid(row=1, column=2, padx=5, pady=5)

        ctk.CTkButton(
            self.remote_frame,
            text="▼ BACKWARD",
            width=130,
            fg_color="#D95B00",
            command=lambda: self.robot.send_command("BACKWARD")
        ).grid(row=2, column=1, padx=5, pady=5)

    # --------------------------------
    # REACTOR ANIMATION
    # --------------------------------

    def animate_reactor(self):

        self.reactor.delete("all")

        w = self.reactor.winfo_width()
        h = self.reactor.winfo_height()

        cx = w // 2
        cy = h // 2

        pulse = 55 + 7 * math.sin(
            self.reactor_frame * 0.12
        )

        for r in (
            pulse + 15,
            pulse + 30,
            pulse + 45
        ):

            self.reactor.create_oval(
                cx-r, cy-r,
                cx+r, cy+r,
                outline="#8B0000",
                width=2
            )

        self.reactor.create_oval(
            cx-pulse,
            cy-pulse,
            cx+pulse,
            cy+pulse,
            fill="#300000",
            outline="#FF2020",
            width=3
        )

        self.reactor.create_text(
            cx,
            cy,
            text="ULTRON",
            fill="#FF2020",
            font=("Arial", 22, "bold")
        )

        self.reactor_frame += 1

        self.after(40, self.animate_reactor)

    # --------------------------------
    # KEYBOARD ROBOT CONTROL
    # --------------------------------

    def handle_keypress(self, event):

        key = event.keysym.lower()

        commands = {
            "w": "FORWARD",
            "s": "BACKWARD",
            "a": "LEFT",
            "d": "RIGHT"
        }

        if key in commands:

            command = commands[key]

            self.robot.send_command(command)

            self.robot_status.configure(
                text=f"LOCAL COMMAND: {command}"
            )

        elif key == "space":

            self.robot.emergency_stop()

            self.robot_status.configure(
                text="EMERGENCY STOP"
            )

    # --------------------------------
    # SEND MESSAGE
    # --------------------------------

    def send_message(self):

        message = self.entry.get().strip()

        if not message:
            return

        self.entry.delete(0, "end")

        self.chat.insert(
            "end",
            f"YOU: {message}\n"
        )

        result = self.system_operator.execute(message)

        if result:

            self.chat.insert(
                "end",
                f"ULTRON: {result}\n\n"
            )

            self.chat.see("end")

            self.voice.speak(result)

            return

        threading.Thread(
            target=self.process_ai_message,
            args=(message,),
            daemon=True
        ).start()

    def process_ai_message(self, message):

        try:

            response = self.ai.get_response(message)

            self.after(
                0,
                lambda: self.display_response(response)
            )

        except Exception as error:

            self.after(
                0,
                lambda: self.display_response(
                    f"AI error: {error}"
                )
            )

    def display_response(self, response):

        self.chat.insert(
            "end",
            f"ULTRON: {response}\n\n"
        )

        self.chat.see("end")

        self.voice.speak(response)

    # --------------------------------
    # MICROPHONE ON / OFF
    # --------------------------------

    def toggle_microphone(self):

        if self.mic_enabled:

            self.mic_enabled = False

            self.mic_button.configure(
                text="MIC OFF",
                fg_color="#8B0000"
            )

            self.status.configure(
                text="● MICROPHONE OFF",
                text_color="#FF5555"
            )

            return

        self.mic_enabled = True

        self.mic_button.configure(
            text="MIC ON",
            fg_color="#008000"
        )

        self.status.configure(
            text="● CONTINUOUS LISTENING",
            text_color="#00FF88"
        )

        self.listen_thread = threading.Thread(
            target=self.listen_continuously,
            daemon=True
        )

        self.listen_thread.start()

    # --------------------------------
    # CONTINUOUS LISTENING
    # --------------------------------

    def listen_continuously(self):

        recognizer = sr.Recognizer()

        recognizer.dynamic_energy_threshold = True

        try:

            with sr.Microphone() as source:

                recognizer.adjust_for_ambient_noise(
                    source,
                    duration=0.5
                )

                while self.mic_enabled:

                    try:

                        audio = recognizer.listen(
                            source,
                            timeout=1,
                            phrase_time_limit=6
                        )

                        message = recognizer.recognize_google(
                            audio,
                            language="en-IN"
                        )

                        message = message.strip()

                        if not message:
                            continue

                        spoken = message.lower().strip()

                        # IMMEDIATE SPEECH INTERRUPTION

                        if spoken in [
                            "stop",
                            "stop speaking",
                            "stop talking",
                            "ultron stop"
                        ]:

                            self.voice.stop()

                            self.after(
                                0,
                                lambda: self.status.configure(
                                    text="● STOPPED - LISTENING",
                                    text_color="#FFD700"
                                )
                            )

                            continue

                        # PROCESS VOICE COMMAND

                        self.after(
                            0,
                            lambda m=message: self.process_voice_message(m)
                        )

                    except sr.WaitTimeoutError:
                        continue

                    except sr.UnknownValueError:
                        continue

                    except sr.RequestError as error:

                        self.after(
                            0,
                            lambda e=error: self.status.configure(
                                text=f"● SPEECH SERVICE ERROR: {e}",
                                text_color="#FF5555"
                            )
                        )

                        threading.Event().wait(2)

        except Exception as error:

            self.after(
                0,
                lambda e=error: self.mic_error(e)
            )

    # --------------------------------
    # PROCESS RECOGNIZED SPEECH
    # --------------------------------

    def process_voice_message(self, message):

        if not self.mic_enabled:
            return

        self.entry.delete(0, "end")
        self.entry.insert(0, message)

        self.send_message()

        self.status.configure(
            text="● CONTINUOUS LISTENING",
            text_color="#00FF88"
        )

    # --------------------------------
    # MICROPHONE ERROR
    # --------------------------------

    def mic_error(self, error):

        self.mic_enabled = False

        self.mic_button.configure(
            text="MIC OFF",
            fg_color="#8B0000"
        )

        self.status.configure(
            text=f"● MICROPHONE ERROR: {error}",
            text_color="#FF5555"
        )


# --------------------------------
# START ULTRON
# --------------------------------

if __name__ == "__main__":

    app = UltronApp()

    app.mainloop()