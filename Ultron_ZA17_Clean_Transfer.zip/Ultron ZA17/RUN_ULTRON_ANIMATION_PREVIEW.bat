@echo off
cd /d "D:\Ultron ZA17"
".venv\Scripts\python.exe" "core\animated_core.py"
if errorlevel 1 pause
