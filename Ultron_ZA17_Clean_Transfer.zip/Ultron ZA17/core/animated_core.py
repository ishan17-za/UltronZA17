import tkinter as tk
import math

class AnimatedAICore(tk.Canvas):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, bg="#05070c", highlightthickness=0, **kwargs)
        self.mode = "ONLINE"
        self.angle = 0
        self.phase = 0.0
        self.running = True
        self.after(30, self.animate)

    def set_mode(self, mode):
        allowed = {"ONLINE", "LISTENING", "THINKING", "SPEAKING", "OFFLINE"}
        mode = str(mode).upper()
        self.mode = mode if mode in allowed else "ONLINE"

    def animate(self):
        if not self.running or not self.winfo_exists():
            return
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        cx, cy = w / 2, h / 2
        s = max(0.4, min(w, h) / 420)
        pulse = math.sin(self.phase) * 7 * s

        for x in range(0, w, 35):
            self.create_line(x, 0, x, h, fill="#101722")
        for y in range(0, h, 35):
            self.create_line(0, y, w, y, fill="#101722")

        for r, color, width in [(135*s+pulse, "#65121a", 2), (119*s, "#ff2633", 2), (103*s, "#9d1822", 2), (78*s+pulse/2, "#ff3945", 3), (62*s, "#ff793d", 2)]:
            self.create_oval(cx-r, cy-r, cx+r, cy+r, outline=color, width=max(1, int(width*s)))

        for i in range(24):
            a = math.radians(self.angle + i*15)
            r1, r2 = (112*s, 130*s) if i % 3 == 0 else (119*s, 126*s)
            self.create_line(cx+math.cos(a)*r1, cy+math.sin(a)*r1,
                             cx+math.cos(a)*r2, cy+math.sin(a)*r2,
                             fill="#ff3945" if i % 3 == 0 else "#84202a", width=2)

        self.create_oval(cx-47*s, cy-47*s, cx+47*s, cy+47*s, fill="#26090e", outline="#ff303b", width=2)
        self.create_oval(cx-25*s, cy-25*s, cx+25*s, cy+25*s, fill="#c9182a", outline="#ff9b55", width=2)

        ey = cy - 11*s
        self.create_polygon(cx-39*s, ey, cx-10*s, ey-8*s, cx-15*s, ey+5*s, fill="#ff3340")
        self.create_polygon(cx+39*s, ey, cx+10*s, ey-8*s, cx+15*s, ey+5*s, fill="#ff3340")

        for i in range(10):
            a = math.radians(-self.angle*1.5 + i*36)
            x, y = cx+math.cos(a)*154*s, cy+math.sin(a)*154*s
            self.create_oval(x-3*s, y-3*s, x+3*s, y+3*s, fill="#ff4a3e", outline="")

        amp = 12 if self.mode in ("LISTENING", "SPEAKING") else 6
        for x in range(-95, 96, 4):
            yy = cy + 174*s + math.sin(x*0.075+self.phase*2)*amp*s
            self.create_line(cx+x*s, yy, cx+(x+2)*s, yy, fill="#ff3542", width=2)

        self.create_text(cx, cy+105*s, text="ULTRON ZA17", fill="#f4f5f7",
                         font=("Arial", max(9, int(15*s)), "bold"))
        self.create_text(cx, cy+130*s, text="AI CORE // "+self.mode, fill="#ff7845",
                         font=("Arial", max(7, int(9*s)), "bold"))

        self.angle = (self.angle + (3 if self.mode == "THINKING" else 2)) % 360
        self.phase += 0.13 if self.mode != "OFFLINE" else 0.03
        self.after(30, self.animate)

    def stop_animation(self):
        self.running = False

if __name__ == "__main__":
    root = tk.Tk()
    root.title("ULTRON ZA17 - Advanced AI Core Preview")
    root.geometry("620x620")
    root.configure(bg="#05070c")
    core = AnimatedAICore(root)
    core.pack(fill="both", expand=True)
    controls = tk.Frame(root, bg="#080d15")
    controls.pack(fill="x")
    for label in ("ONLINE", "LISTENING", "THINKING", "SPEAKING"):
        tk.Button(controls, text=label, command=lambda v=label: core.set_mode(v),
                  bg="#241018", fg="white", relief="flat", padx=8, pady=8).pack(
                      side="left", expand=True, fill="x", padx=3, pady=6)
    root.protocol("WM_DELETE_WINDOW", lambda: (core.stop_animation(), root.destroy()))
    root.mainloop()
