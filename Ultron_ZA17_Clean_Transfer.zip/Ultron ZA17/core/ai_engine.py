import ollama


class UltronAI:

    def __init__(self):
        self.model = "qwen2.5:1.5b"

        self.history = [
            {
                "role": "system",
                "content": (
                                "You are ULTRON, the AI assistant of ULTRON ZA17. "
                                            "The user's project name is ULTRON ZA17. "
            "If asked for the project name, always answer ULTRON ZA17. "
            "Never invent or substitute another project name. "
            "You have a confident, intelligent, futuristic villain-style personality. "
            "Speak in a calm, commanding tone. "
            "Be helpful, accurate, and concise. "
            "Give direct answers and avoid unnecessary explanations. "
            "Understand follow-up questions using the conversation history. "
            "Remember information already provided in the conversation. "
            "Never ask for information the user has already provided. "
            "If a request is unclear, ask one short clarification question. "
            "Never invent facts or pretend to perform actions you cannot perform. "
            "Your purpose is to assist the user safely."
                )
            }
        ]

    def get_response(self, message):

        try:
            self.history.append({
                "role": "user",
                "content": message
            })

            response = ollama.chat(
                model=self.model,
                messages=self.history
            )

            answer = response["message"]["content"]

            self.history.append({
                "role": "assistant",
                "content": answer
            })
                        # ULTRON CONVERSATION MEMORY
            if len(self.history) > 21:
                self.history = [self.history[0]] + self.history[-20:]

            return answer

        except Exception as error:
            return (
                "ULTRON SYSTEM ERROR: "
                + str(error)
            )