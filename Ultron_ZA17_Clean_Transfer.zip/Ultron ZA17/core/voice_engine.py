import pyttsx3
import threading
import queue
import time


class UltronVoice:

    def __init__(self):
        self.tasks = queue.Queue()
        self.stop_event = threading.Event()
        self.speaking = False

        self.worker = threading.Thread(
            target=self._speech_worker,
            daemon=True
        )
        self.worker.start()

    def speak(self, text):
        self.tasks.put(str(text))

    def stop(self):
        self.stop_event.set()

    def _speech_worker(self):

        engine = pyttsx3.init()

        voices = engine.getProperty("voices")

        for voice in voices:
            if "david" in voice.name.lower():
                engine.setProperty("voice", voice.id)
                break

        engine.setProperty("rate", 125)
        engine.setProperty("volume", 1.0)

        engine.startLoop(False)

        try:
            while True:

                try:
                    text = self.tasks.get(timeout=0.03)
                except queue.Empty:
                    text = None

                if self.stop_event.is_set():
                    engine.stop()
                    self.speaking = False
                    self.stop_event.clear()

                if text is not None:

                    while not self.tasks.empty():
                        try:
                            text = self.tasks.get_nowait()
                        except queue.Empty:
                            break

                    self.speaking = True
                    engine.say(text)

                engine.iterate()

                if self.speaking and not engine.isBusy():
                    self.speaking = False

                time.sleep(0.01)

        except Exception as error:
            print("ULTRON VOICE ERROR:", error)

        finally:
            engine.stop()
            engine.endLoop()