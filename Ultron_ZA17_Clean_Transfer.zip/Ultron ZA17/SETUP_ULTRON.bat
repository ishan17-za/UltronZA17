@echo off
setlocal
cd /d "%~dp0"
echo =====================================
echo       ULTRON ZA17 - FIRST SETUP
echo =====================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher was not found.
  echo Install Python 3.12 from https://www.python.org/downloads/ and select "Add Python to PATH".
  pause
  exit /b 1
)
py -3.12 --version
if errorlevel 1 (
  echo Python 3.12 is required. Install it from https://www.python.org/downloads/ then run this file again.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" py -3.12 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto failed
python -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo.
echo Setup complete. Run RUN_ULTRON.bat to start the desktop app.
pause
exit /b 0
:failed
echo Setup did not complete. Check your internet connection and try again.
pause
exit /b 1
