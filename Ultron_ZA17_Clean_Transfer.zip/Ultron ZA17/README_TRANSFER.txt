ULTRON ZA17 - TRANSFER PACKAGE
==============================

CONTENTS
- Original project source files and assets
- requirements.txt: Python packages used by the project
- SETUP_ULTRON.bat: creates a new virtual environment and installs packages
- RUN_ULTRON.bat: starts the desktop application

ON YOUR FRIEND'S WINDOWS PC
1. Install Python 3.12 (64-bit) from https://www.python.org/downloads/ .
   During installation, enable "Add Python to PATH".
2. Extract this ZIP file completely.
3. Open the extracted "Ultron ZA17" folder.
4. Double-click SETUP_ULTRON.bat and wait for installation to finish.
5. Double-click RUN_ULTRON.bat.

NOTES
- The old .venv folder was intentionally excluded. A virtual environment is
  machine-specific; the setup script creates a fresh one on your friend's PC.
- Python itself is not bundled in this ZIP. Install Python 3.12 separately.
- The previous ULTRON_WEB_ACCESS_KEY.txt was excluded so the old access key
  is not shared. The web server needs a new private key configured separately
  if you use the web interface. Do not publish that key on GitHub.
- The project uses Ollama for its local AI engine. Install Ollama separately
  from https://ollama.com/ and, in a terminal, run:
      ollama pull qwen2.5:1.5b
  Keep Ollama running when using AI features.
- Microphone features may need an additional Windows audio dependency.
- Hardware features need the corresponding hardware and configuration.

This package preserves the source files; it has not been fully tested on the
recipient's computer. Some optional features may need additional setup.
