# =====================================
# ULTRON ZA17 - CONFIGURATION
# =====================================

APP_NAME = "ULTRON ZA17"
APP_VERSION = "1.0.0"

ASSISTANT_NAME = "ULTRON"
ASSISTANT_PERSONALITY = "Dark, Intelligent, Confident"

WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 750

THEME = "dark"
PRIMARY_COLOR = "#00BFFF"
BACKGROUND_COLOR = "#080B16"

VOICE_ENABLED = True
AI_ENABLED = True

WELCOME_MESSAGE = (
    "System online. "
    "I am ULTRON ZA17. "
    "All systems are ready."
)