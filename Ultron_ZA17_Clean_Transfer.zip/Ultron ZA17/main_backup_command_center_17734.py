import math
import random
import threading
import time
import tkinter as tk

import customtkinter as ctk
import speech_recognition as sr

from core.ai_engine import UltronAI
from core.voice_engine import UltronVoice
from modules.robot_controller import RobotController
from modules.system_operator import SystemOperator


ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")


class UltronApp(ctk.CTk):
    """ULTRON ZA17 desktop interface with a state-reactive animated reactor."""

    COLORS = {
        "IDLE": "#FF334F",
        "LISTENING": "#FF4D2E",
        "THINKING": "#FF9B42",
        "SPEAKING": "#FF263D",
        "EXECUTING": "#FF7043",
        "ERROR": "#FF5252",
    }

    MODE_LABELS = {
        "IDLE": "SYSTEM STANDBY",
        "LISTENING": "VOICE INPUT ACTIVE",
        "THINKING": "NEURAL PROCESSING",
        "SPEAKING": "VOICE OUTPUT ACTIVE",
        "EXECUTING": "COMMAND EXECUTION",
        "ERROR": "SYSTEM ATTENTION REQUIRED",
    }

    def __init__(self):
        super().__init__()

        self.system_operator = SystemOperator()
        self.ai = UltronAI()
        self.robot = RobotController()
        self.voice = UltronVoice()

        self.mic_enabled = False
        self.listen_thread = None
        self.mic_lock = threading.Lock()

        self.animation_frame = 0
        self.animation_mode = "IDLE"
        self.animation_running = True
        self._speech_monitor_running = False
        self._closing = False

        self.title("ULTRON ZA17")
        self.geometry("1240x820")
        self.minsize(1000, 700)
        self.configure(fg_color="#070A11")
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self.create_interface()
        self.bind("<KeyPress>", self.handle_keypress)
        self.focus_set()
        self.after(120, self.animate_reactor)

    # ---------------------------------------------------------
    # INTERFACE
    # ---------------------------------------------------------

    def create_interface(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        header = ctk.CTkFrame(self, fg_color="#0B101A", corner_radius=0, height=76)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        header.grid_propagate(False)

        brand = ctk.CTkFrame(header, fg_color="transparent")
        brand.pack(side="left", padx=26, pady=10)
        ctk.CTkLabel(
            brand, text="ULTRON", font=("Arial", 27, "bold"),
            text_color="#F0F2F5"
        ).pack(anchor="w")
        ctk.CTkLabel(
            brand, text="ZA17  /  ARTIFICIAL INTELLIGENCE SYSTEM",
            font=("Consolas", 10, "bold"), text_color="#B34A4A"
        ).pack(anchor="w")

        self.header_status = ctk.CTkLabel(
            header, text="● SYSTEM ONLINE", font=("Consolas", 12, "bold"),
            text_color="#FF5265"
        )
        self.header_status.pack(side="right", padx=28)

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.grid(row=1, column=0, sticky="nsew", padx=18, pady=(15, 8))
        body.grid_columnconfigure(0, weight=6, uniform="body")
        body.grid_columnconfigure(1, weight=5, uniform="body")
        body.grid_rowconfigure(0, weight=1)

        # Visual/reactor panel
        visual_panel = ctk.CTkFrame(
            body, fg_color="#0A0E17", border_width=1,
            border_color="#361721", corner_radius=16
        )
        visual_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        visual_panel.grid_rowconfigure(1, weight=1)
        visual_panel.grid_columnconfigure(0, weight=1)

        visual_heading = ctk.CTkFrame(visual_panel, fg_color="transparent")
        visual_heading.grid(row=0, column=0, sticky="ew", padx=18, pady=(15, 3))
        ctk.CTkLabel(
            visual_heading, text="CORE REACTOR", font=("Consolas", 12, "bold"),
            text_color="#D6D9E0"
        ).pack(side="left")
        ctk.CTkLabel(
            visual_heading, text="LIVE SYSTEM VISUALIZER", font=("Consolas", 9),
            text_color="#77515B"
        ).pack(side="right")

        self.reactor = tk.Canvas(
            visual_panel, height=470, bg="#080B12", highlightthickness=0,
            bd=0
        )
        self.reactor.grid(row=1, column=0, sticky="nsew", padx=10, pady=8)
        self.reactor.bind("<Configure>", lambda _event: self.draw_reactor())

        self.reactor_footer = ctk.CTkFrame(visual_panel, fg_color="transparent")
        self.reactor_footer.grid(row=2, column=0, sticky="ew", padx=18, pady=(0, 13))
        self.mode_dot = ctk.CTkLabel(
            self.reactor_footer, text="●", font=("Arial", 13, "bold"),
            text_color=self.COLORS["IDLE"]
        )
        self.mode_dot.pack(side="left", padx=(0, 7))
        self.mode_text = ctk.CTkLabel(
            self.reactor_footer, text=self.MODE_LABELS["IDLE"],
            font=("Consolas", 10, "bold"), text_color="#C9A0A8"
        )
        self.mode_text.pack(side="left")
        ctk.CTkLabel(
            self.reactor_footer, text="ZA17 // CORE 01", font=("Consolas", 9),
            text_color="#66404B"
        ).pack(side="right")

        # Communications panel
        console = ctk.CTkFrame(
            body, fg_color="#0A0E17", border_width=1,
            border_color="#252D3A", corner_radius=16
        )
        console.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        console.grid_rowconfigure(1, weight=1)
        console.grid_columnconfigure(0, weight=1)

        console_heading = ctk.CTkFrame(console, fg_color="transparent")
        console_heading.grid(row=0, column=0, sticky="ew", padx=17, pady=(15, 8))
        ctk.CTkLabel(
            console_heading, text="COMMUNICATION LINK",
            font=("Consolas", 12, "bold"), text_color="#D6D9E0"
        ).pack(side="left")
        ctk.CTkLabel(
            console_heading, text="ENCRYPTED LOCAL CONSOLE",
            font=("Consolas", 9), text_color="#657184"
        ).pack(side="right")

        self.chat = ctk.CTkTextbox(
            console, font=("Consolas", 12), fg_color="#080C14",
            text_color="#E4E7EC", border_width=1, border_color="#1D2835",
            corner_radius=10, wrap="word"
        )
        self.chat.grid(row=1, column=0, sticky="nsew", padx=14, pady=5)
        self.chat.insert(
            "end",
            "ULTRON // SYSTEM INITIALIZED\n"
            "────────────────────────────────\n"
            "System online. All local modules loaded.\n"
            "Awaiting your command.\n\n"
        )

        self.entry = ctk.CTkEntry(
            console, height=42, placeholder_text="Enter a command or ask ULTRON...",
            font=("Consolas", 12), fg_color="#101722",
            border_color="#55303B"
        )
        self.entry.grid(row=2, column=0, sticky="ew", padx=14, pady=(10, 8))
        self.entry.bind("<Return>", lambda _event: self.send_message())

        command_row = ctk.CTkFrame(console, fg_color="transparent")
        command_row.grid(row=3, column=0, sticky="ew", padx=14, pady=(0, 14))
        command_row.grid_columnconfigure((0, 1), weight=1)

        self.send_button = ctk.CTkButton(
            command_row, text="TRANSMIT", height=38, command=self.send_message,
            fg_color="#8F2035", hover_color="#C52D49",
            font=("Consolas", 11, "bold")
        )
        self.send_button.grid(row=0, column=0, sticky="ew", padx=(0, 5))

        self.mic_button = ctk.CTkButton(
            command_row, text="MIC OFF", height=38, command=self.toggle_microphone,
            fg_color="#29202A", hover_color="#6F2636",
            font=("Consolas", 11, "bold")
        )
        self.mic_button.grid(row=0, column=1, sticky="ew", padx=(5, 0))

        # Robot panel remains available while hardware is not connected.
        robot_panel = ctk.CTkFrame(
            self, fg_color="#0B1019", border_width=1,
            border_color="#252D3A", corner_radius=14
        )
        robot_panel.grid(row=2, column=0, sticky="ew", padx=18, pady=(3, 16))
        robot_panel.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(
            robot_panel, text="ROBOT LINK", font=("Consolas", 11, "bold"),
            text_color="#D6D9E0"
        ).grid(row=0, column=0, padx=(16, 10), pady=12, sticky="w")

        self.robot_status = ctk.CTkLabel(
            robot_panel, text="CONTROLLER READY  •  HARDWARE NOT CONNECTED",
            font=("Consolas", 9), text_color="#8C9AAA"
        )
        self.robot_status.grid(row=0, column=1, padx=8, pady=12, sticky="w")

        remote = ctk.CTkFrame(robot_panel, fg_color="transparent")
        remote.grid(row=0, column=2, padx=12, pady=7, sticky="e")
        self._robot_button(remote, "▲", "FORWARD", 0, 1)
        self._robot_button(remote, "◀", "LEFT", 1, 0)
        self._robot_button(remote, "■ STOP", "STOP", 1, 1, stop=True)
        self._robot_button(remote, "▶", "RIGHT", 1, 2)
        self._robot_button(remote, "▼", "BACKWARD", 2, 1)

    def _robot_button(self, parent, label, command, row, column, stop=False):
        button = ctk.CTkButton(
            parent, text=label, width=72 if stop else 48, height=27,
            font=("Consolas", 10, "bold"),
            fg_color="#872137" if stop else "#242B37",
            hover_color="#C12D49" if stop else "#414B5C",
            command=lambda c=command: self.send_robot_command(c)
        )
        button.grid(row=row, column=column, padx=3, pady=2)

    # ---------------------------------------------------------
    # ADVANCED REACTOR ANIMATION
    # ---------------------------------------------------------

    def set_animation_mode(self, mode):
        if mode not in self.COLORS:
            mode = "IDLE"
        self.animation_mode = mode
        color = self.COLORS[mode]
        self.mode_dot.configure(text_color=color)
        self.mode_text.configure(text=self.MODE_LABELS[mode])
        self.header_status.configure(
            text=f"● {self.MODE_LABELS[mode]}", text_color=color
        )

    def draw_reactor(self):
        canvas = self.reactor
        canvas.delete("all")
        w = max(canvas.winfo_width(), 300)
        h = max(canvas.winfo_height(), 300)
        cx, cy = w / 2, h / 2 - 8
        frame = self.animation_frame
        mode = self.animation_mode
        color = self.COLORS[mode]
        pulse = math.sin(frame * 0.075)
        breathe = 1.0 + 0.025 * pulse

        # Subtle technical grid and edge marks.
        for x in range(18, w, 34):
            canvas.create_line(x, 0, x, h, fill="#111923", width=1)
        for y in range(12, h, 34):
            canvas.create_line(0, y, w, y, fill="#111923", width=1)
        canvas.create_rectangle(8, 8, w - 8, h - 8, outline="#28303D", width=1)
        canvas.create_line(18, 24, 58, 24, fill=color, width=2)
        canvas.create_line(w - 58, h - 24, w - 18, h - 24, fill=color, width=2)

        # Radar-like radial traces.
        outer_r = min(w * 0.34, h * 0.39, 178)
        for i in range(48):
            angle = math.radians(i * 7.5 + frame * 0.35)
            inner = outer_r + (9 if i % 4 == 0 else 16)
            outer = outer_r + (22 if i % 4 == 0 else 19)
            x1, y1 = cx + math.cos(angle) * inner, cy + math.sin(angle) * inner
            x2, y2 = cx + math.cos(angle) * outer, cy + math.sin(angle) * outer
            canvas.create_line(
                x1, y1, x2, y2,
                fill=color if i % 4 == 0 else "#55303B",
                width=2 if i % 4 == 0 else 1
            )

        # Concentric core rings with independently rotating arc segments.
        radii = [outer_r, outer_r * 0.83, outer_r * 0.66]
        for index, radius in enumerate(radii):
            r = radius * (breathe if index == 2 else 1.0)
            canvas.create_oval(
                cx-r, cy-r, cx+r, cy+r,
                outline="#45202D" if index else "#3B2630", width=1
            )
            start = (frame * (1.8 + index * 0.65) + index * 115) % 360
            canvas.create_arc(
                cx-r, cy-r, cx+r, cy+r,
                start=start, extent=72 + index * 18,
                style=tk.ARC, outline=color, width=3 if index == 0 else 2
            )
            canvas.create_arc(
                cx-r, cy-r, cx+r, cy+r,
                start=(start + 178) % 360, extent=34 + index * 10,
                style=tk.ARC, outline="#B84452", width=2
            )

        # Orbiting particles/nodes.
        for i in range(12):
            angle = math.radians(frame * (1.2 if i % 2 == 0 else -0.9) + i * 30)
            orbit = outer_r * (0.73 if i % 2 == 0 else 0.91)
            px = cx + math.cos(angle) * orbit
            py = cy + math.sin(angle) * orbit
            size = 2.0 + (1.4 if i % 3 == 0 else 0.0)
            node_color = color if i % 3 == 0 else "#A44755"
            canvas.create_oval(
                px-size, py-size, px+size, py+size,
                fill=node_color, outline=""
            )
            if i % 3 == 0:
                canvas.create_oval(
                    px-size*2.4, py-size*2.4, px+size*2.4, py+size*2.4,
                    outline="#612333", width=1
                )

        # Core glow layers.
        core_r = outer_r * 0.39 * (1.0 + 0.04 * pulse)
        for scale, fill in [(1.55, "#170C14"), (1.32, "#24101A"), (1.12, "#35101B")]:
            r = core_r * scale
            canvas.create_oval(cx-r, cy-r, cx+r, cy+r, fill=fill, outline="#632334", width=1)
        canvas.create_oval(
            cx-core_r, cy-core_r, cx+core_r, cy+core_r,
            fill="#5A1422", outline=color, width=3
        )

        # Central geometric reactor crystal.
        crystal_r = core_r * 0.67
        points = []
        for i in range(6):
            angle = math.radians(i * 60 - 30 + frame * 0.15)
            points.extend([cx + math.cos(angle) * crystal_r,
                           cy + math.sin(angle) * crystal_r])
        canvas.create_polygon(points, fill="#9E1D32", outline="#FF9AA5", width=2)
        canvas.create_oval(
            cx-8-2*pulse, cy-8-2*pulse, cx+8+2*pulse, cy+8+2*pulse,
            fill="#FFE4E7", outline=color, width=2
        )
        canvas.create_text(
            cx, cy + core_r + 29, text="U L T R O N",
            fill="#F0DDE1", font=("Arial", 16, "bold")
        )
        canvas.create_text(
            cx, cy + core_r + 49, text="ZA17  /  NEURAL CORE",
            fill="#A65A68", font=("Consolas", 8, "bold")
        )

        # Animated waveform at the bottom of the reactor panel.
        wave_y = h - 43
        bar_count = 52
        usable = max(w - 80, 200)
        bar_gap = usable / bar_count
        for i in range(bar_count):
            wave = (math.sin(frame * 0.18 + i * 0.48) +
                    0.45 * math.sin(frame * 0.09 - i * 0.22))
            if mode == "IDLE":
                height = 3 + abs(wave) * 4
            elif mode == "LISTENING":
                height = 5 + abs(wave) * 17
            elif mode == "THINKING":
                height = 5 + abs(math.sin(frame * 0.25 + i * 0.2)) * 22
            elif mode == "SPEAKING":
                height = 4 + abs(wave) * 20
            else:
                height = 4 + abs(wave) * 13
            x = (w - usable) / 2 + i * bar_gap
            canvas.create_line(
                x, wave_y - height / 2, x, wave_y + height / 2,
                fill=color if i % 4 == 0 else "#763141", width=2
            )

        # Scanning beam.
        scan_y = 20 + ((frame * 3) % max(h - 40, 1))
        canvas.create_line(18, scan_y, w - 18, scan_y, fill="#4A1C2A", width=1)

        self.animation_frame += 1

    def animate_reactor(self):
        if self._closing or not self.animation_running:
            return
        self.draw_reactor()
        self.after(40, self.animate_reactor)  # Approximately 25 frames per second.

    # ---------------------------------------------------------
    # ROBOT CONTROLS
    # ---------------------------------------------------------

    def send_robot_command(self, command):
        if command == "STOP":
            result = self.robot.emergency_stop()
        else:
            result = self.robot.send_command(command)
        self.robot_status.configure(text=result.upper(), text_color="#FF9B42")

    def handle_keypress(self, event):
        # Do not hijack letters while the user is typing in an input control.
        widget_class = event.widget.winfo_class()
        if widget_class in ("Entry", "Text") or "Entry" in widget_class or "Text" in widget_class:
            return
        commands = {
            "w": "FORWARD", "s": "BACKWARD",
            "a": "LEFT", "d": "RIGHT"
        }
        key = event.keysym.lower()
        if key in commands:
            self.send_robot_command(commands[key])
        elif key == "space":
            self.send_robot_command("STOP")

    # ---------------------------------------------------------
    # TEXT AND AI
    # ---------------------------------------------------------

    def append_chat(self, text):
        self.chat.insert("end", text)
        self.chat.see("end")

    def send_message(self):
        message = self.entry.get().strip()
        if not message:
            return
        self.entry.delete(0, "end")
        self.append_chat(f"YOU  //  {message}\n")

        self.set_animation_mode("THINKING")
        result = self.system_operator.execute(message)
        if result:
            self.append_chat(f"ULTRON  //  {result}\n\n")
            self.speak_response(result)
            return

        self.send_button.configure(state="disabled", text="PROCESSING...")
        threading.Thread(
            target=self.process_ai_message, args=(message,), daemon=True
        ).start()

    def process_ai_message(self, message):
        try:
            response = self.ai.get_response(message)
        except Exception as error:
            response = f"AI error: {error}"
        self.after(0, lambda r=response: self.display_response(r))

    def display_response(self, response):
        self.send_button.configure(state="normal", text="TRANSMIT")
        self.append_chat(f"ULTRON  //  {response}\n\n")
        self.speak_response(response)

    def speak_response(self, response):
        self.set_animation_mode("SPEAKING")
        self.voice.speak(response)
        if not self._speech_monitor_running:
            self._speech_monitor_running = True
            self.after(250, self.check_speech_status)

    def check_speech_status(self):
        if self._closing:
            return
        pending = False
        try:
            pending = (not self.voice.tasks.empty()) or bool(self.voice.speaking)
        except Exception:
            pending = bool(getattr(self.voice, "speaking", False))
        if pending:
            self.after(250, self.check_speech_status)
        else:
            self._speech_monitor_running = False
            self.set_animation_mode("LISTENING" if self.mic_enabled else "IDLE")

    # ---------------------------------------------------------
    # MICROPHONE
    # ---------------------------------------------------------

    def toggle_microphone(self):
        if self.mic_enabled:
            self.mic_enabled = False
            self.mic_button.configure(text="MIC OFF", fg_color="#29202A")
            self.set_animation_mode("IDLE")
            return

        self.mic_enabled = True
        self.mic_button.configure(text="MIC ON", fg_color="#8F2035")
        self.set_animation_mode("LISTENING")
        self.listen_thread = threading.Thread(
            target=self.listen_continuously, daemon=True
        )
        self.listen_thread.start()

    def listen_continuously(self):
        recognizer = sr.Recognizer()
        recognizer.dynamic_energy_threshold = True
        try:
            with sr.Microphone() as source:
                recognizer.adjust_for_ambient_noise(source, duration=0.5)
                while self.mic_enabled and not self._closing:
                    try:
                        audio = recognizer.listen(
                            source, timeout=1, phrase_time_limit=6
                        )
                        message = recognizer.recognize_google(
                            audio, language="en-IN"
                        ).strip()
                        if not message:
                            continue

                        if message.lower().strip() in {
                            "stop", "stop speaking", "stop talking", "ultron stop"
                        }:
                            self.voice.stop()
                            self.after(0, lambda: self.set_animation_mode(
                                "LISTENING" if self.mic_enabled else "IDLE"
                            ))
                            continue

                        self.after(
                            0, lambda m=message: self.process_voice_message(m)
                        )
                    except sr.WaitTimeoutError:
                        continue
                    except sr.UnknownValueError:
                        continue
                    except sr.RequestError as error:
                        self.after(0, lambda e=error: self.show_mic_error(e))
                        time.sleep(2)
        except Exception as error:
            self.after(0, lambda e=error: self.show_mic_error(e))

    def process_voice_message(self, message):
        if not self.mic_enabled:
            return
        self.entry.delete(0, "end")
        self.entry.insert(0, message)
        self.send_message()

    def show_mic_error(self, error):
        self.mic_enabled = False
        self.mic_button.configure(text="MIC OFF", fg_color="#29202A")
        self.set_animation_mode("ERROR")
        self.append_chat(f"SYSTEM  //  MICROPHONE ERROR: {error}\n\n")

    # ---------------------------------------------------------
    # SHUTDOWN
    # ---------------------------------------------------------

    def on_close(self):
        self._closing = True
        self.animation_running = False
        self.mic_enabled = False
        try:
            self.voice.stop()
        except Exception:
            pass
        self.destroy()


if __name__ == "__main__":
    app = UltronApp()
    app.mainloop()
