import os
import re
import webbrowser
import subprocess

from urllib.parse import quote_plus

try:
    import yt_dlp
except ImportError:
    yt_dlp = None


class SystemOperator:

    def __init__(self):
        self.last_query = ""
        self.last_destination = "google"

    # -----------------------------------
    # CHROME LOCATION
    # -----------------------------------

    def get_chrome_path(self):

        paths = [
            os.path.expandvars(
                r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"
            ),
            os.path.expandvars(
                r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
            ),
            os.path.expandvars(
                r"%LocalAppData%\Google\Chrome\Application\chrome.exe"
            )
        ]

        for path in paths:
            if os.path.exists(path):
                return path

        return None

    # -----------------------------------
    # OPEN APPLICATIONS
    # -----------------------------------

    def open_app(self, name):

        apps = {
            "notepad": ["notepad.exe"],
            "calculator": ["calc.exe"],
            "file explorer": ["explorer.exe"],
            "explorer": ["explorer.exe"],
            "vscode": ["code"],
            "visual studio code": ["code"]
        }

        if name == "chrome":

            chrome = self.get_chrome_path()

            if chrome:
                subprocess.Popen([chrome])
                return "Opening Google Chrome."

            return "Google Chrome was not found."

        if name in apps:

            try:
                subprocess.Popen(apps[name])
                return f"Opening {name}."

            except Exception as error:
                return f"Could not open {name}: {error}"

        return None

    # -----------------------------------
    # EXTRACT SEARCH QUERY
    # -----------------------------------

    def clean_query(self, command):

        query = command

        phrases = [
            "open youtube and search for",
            "open youtube and search",
            "search youtube for",
            "search on youtube for",
            "search in microsoft store for",
            "search microsoft store for",
            "find on wikipedia",
            "search wikipedia for",
            "look up on wikipedia",
            "search on google for",
            "search in google for",
            "search google for",
            "search in chrome for",
            "search chrome for",
            "open chrome and search for",
            "open chrome and search",
            "find information about",
            "find information on",
            "look up",
            "search for",
            "search",
            "find me",
            "find",
            "show me",
            "tell me about",
            "play me",
            "play",
            "watch",
            "listen to",
            "put on",
            "open",
            "launch",
            "start",
            "on youtube",
            "in youtube",
            "on google",
            "in google",
            "in chrome",
            "on chrome",
            "on wikipedia",
            "in wikipedia",
            "on microsoft store",
            "in microsoft store",
            "microsoft store",
            "wikipedia",
            "youtube",
            "google",
            "chrome",
            "the first video",
            "first video",
            "and play",
            "please",
            "for me"
        ]

        for phrase in phrases:
            query = re.sub(
                re.escape(phrase),
                " ",
                query,
                flags=re.IGNORECASE
            )

        query = re.sub(r"\s+", " ", query).strip(" .?!")

        return query

    # -----------------------------------
    # GOOGLE SEARCH
    # -----------------------------------

    def google_search(self, query):

        url = (
            "https://www.google.com/search?q="
            + quote_plus(query)
        )

        webbrowser.open(url)

        self.last_query = query
        self.last_destination = "google"

        return f"Searching Google for {query}."

    # -----------------------------------
    # CHROME SEARCH
    # -----------------------------------

    def chrome_search(self, query):

        url = (
            "https://www.google.com/search?q="
            + quote_plus(query)
        )

        chrome = self.get_chrome_path()

        if chrome:
            subprocess.Popen([chrome, url])
        else:
            webbrowser.open(url)

        self.last_query = query
        self.last_destination = "chrome"

        return f"Searching Chrome for {query}."

    # -----------------------------------
    # YOUTUBE SEARCH AND PLAYBACK
    # -----------------------------------

    def youtube_search(self, query):

        if not query:
            return "What should I find on YouTube?"

        if yt_dlp is None:
            return "Please install yt-dlp first."

        try:

            options = {
                "quiet": True,
                "extract_flat": True,
                "skip_download": True,
                "noplaylist": True
            }

            with yt_dlp.YoutubeDL(options) as ydl:

                results = ydl.extract_info(
                    f"ytsearch1:{query}",
                    download=False
                )

            entries = results.get("entries") or []

            if not entries:
                return f"No matching video found for {query}."

            video_id = entries[0].get("id")

            if not video_id:
                return "I couldn't find a playable video."

            video_url = (
                "https://www.youtube.com/watch?v="
                + video_id
            )

            webbrowser.open(video_url)

            self.last_query = query
            self.last_destination = "youtube"

            return f"Opening the first YouTube result for {query}."

        except Exception as error:

            return f"YouTube search failed: {error}"

    # -----------------------------------
    # WIKIPEDIA SEARCH
    # -----------------------------------

    def wikipedia_search(self, query):

        url = (
            "https://en.wikipedia.org/w/index.php?search="
            + quote_plus(query)
        )

        webbrowser.open(url)

        self.last_query = query
        self.last_destination = "wikipedia"

        return f"Searching Wikipedia for {query}."

    # -----------------------------------
    # MICROSOFT STORE SEARCH
    # -----------------------------------

    def microsoft_search(self, query):

        try:

            store_url = (
                "ms-windows-store://search/?query="
                + quote_plus(query)
            )

            os.startfile(store_url)

            self.last_query = query
            self.last_destination = "microsoft"

            return f"Searching Microsoft Store for {query}."

        except Exception:

            return "Microsoft Store could not be opened."

    # -----------------------------------
    # NATURAL LANGUAGE SYSTEM OPERATOR
    # -----------------------------------

    def execute(self, command):

        if not command:
            return None

        original = command.strip()
        text = original.lower().strip()

        # OPEN APPLICATIONS

        app_patterns = {
            "chrome": ["chrome", "browser", "web browser"],
            "notepad": ["notepad"],
            "calculator": ["calculator", "calc"],
            "file explorer": ["file explorer", "explorer"],
            "vscode": ["vscode", "visual studio code"]
        }

        for app, keywords in app_patterns.items():

            if any(
                re.search(r"\b" + re.escape(word) + r"\b", text)
                for word in keywords
            ):

                if re.match(
                    r"^(open|launch|start)\b",
                    text
                ) and not any(
                    word in text for word in [
                        "search", "find", "play", "watch"
                    ]
                ):

                    return self.open_app(app)

        # DETECT DESTINATION

        if any(x in text for x in [
            "microsoft store", "windows store"
        ]):
            destination = "microsoft"

        elif "wikipedia" in text:
            destination = "wikipedia"

        elif "youtube" in text:
            destination = "youtube"

        elif "chrome" in text or "browser" in text:
            destination = "chrome"

        elif "google" in text:
            destination = "google"

        elif any(x in text for x in [
            "play", "song", "music", "watch",
            "video", "listen to"
        ]):
            destination = "youtube"

        elif any(x in text for x in [
            "search", "find", "look up",
            "information about", "tell me about"
        ]):
            destination = "google"

        else:
            return None

        # EXTRACT TOPIC

        query = self.clean_query(original)

        # FOLLOW-UP CONTEXT

        if not query and self.last_query:
            query = self.last_query

        if not query:
            return "What would you like me to search for?"

        # EXECUTE ACTION

        if destination == "youtube":
            return self.youtube_search(query)

        elif destination == "wikipedia":
            return self.wikipedia_search(query)

        elif destination == "microsoft":
            return self.microsoft_search(query)

        elif destination == "chrome":
            return self.chrome_search(query)

        elif destination == "google":
            return self.google_search(query)

        return None