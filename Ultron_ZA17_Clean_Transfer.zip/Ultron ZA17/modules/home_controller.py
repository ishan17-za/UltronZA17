"""ULTRON ZA17 home-appliance control abstraction.

Safe default: simulation mode only. No mains appliance is controlled by this
module. A real device adapter can be added later after the user's compatible
smart-home controller and devices are selected and securely configured.
"""

from __future__ import annotations

import re
from typing import Optional


class HomeController:
    """Tracks supported home devices and parses a small set of safe commands.

    The default backend is deliberately simulated. The UI and voice/AI command
    path can therefore be tested before any physical smart-home equipment is
    installed. `hardware_connected` remains False until a real adapter exists.
    """

    DEVICES = {
        "LIGHTS": ("light", "lights", "lamp", "lamps"),
        "TELEVISION": ("tv", "television"),
        "FAN": ("fan", "fans"),
    }
    FAN_SPEED_MIN = 1
    FAN_SPEED_MAX = 5

    def __init__(self) -> None:
        self.backend = "SIMULATION"
        self.hardware_connected = False
        self.devices = {
            "LIGHTS": {"is_on": False},
            "TELEVISION": {"is_on": False},
            "FAN": {"is_on": False, "speed": 0},
        }

    @staticmethod
    def _normalise(text: str) -> str:
        return re.sub(r"\s+", " ", str(text or "").strip().lower())

    @classmethod
    def _find_device(cls, text: str) -> Optional[str]:
        for device, aliases in cls.DEVICES.items():
            for alias in aliases:
                if re.search(rf"\b{re.escape(alias)}\b", text):
                    return device
        return None

    def get_device_status(self, device: str) -> dict:
        name = str(device).upper()
        if name not in self.devices:
            raise ValueError(f"Unsupported home device: {device}")
        return dict(self.devices[name])

    def get_status(self) -> dict:
        return {name: dict(state) for name, state in self.devices.items()}

    def status_text(self) -> str:
        lines = ["HOME DEVICE STATUS — SIMULATION ONLY"]
        for name, state in self.devices.items():
            power = "ON" if state["is_on"] else "OFF"
            suffix = f" | SPEED {state['speed']}/5" if name == "FAN" else ""
            lines.append(f"{name}: {power}{suffix}")
        lines.append("No physical appliance has been switched; no hardware is connected.")
        return "\n".join(lines)

    def set_device(self, device: str, is_on: bool) -> str:
        name = str(device).upper()
        if name not in self.devices:
            return f"Unsupported device: {device}."
        state = self.devices[name]
        state["is_on"] = bool(is_on)
        if name == "FAN" and not is_on:
            state["speed"] = 0
        elif name == "FAN" and is_on and state["speed"] == 0:
            state["speed"] = 1
        power = "ON" if state["is_on"] else "OFF"
        return (
            f"{name} set to {power} in ULTRON simulation mode. "
            "This is only a software demonstration; no physical appliance was switched."
        )

    def toggle_device(self, device: str) -> str:
        name = str(device).upper()
        if name not in self.devices:
            return f"Unsupported device: {device}."
        return self.set_device(name, not self.devices[name]["is_on"])

    def set_fan_speed(self, speed: int) -> str:
        try:
            value = int(speed)
        except (TypeError, ValueError):
            return "Fan speed must be a whole number from 1 to 5."
        if value < self.FAN_SPEED_MIN or value > self.FAN_SPEED_MAX:
            return "Fan speed must be between 1 and 5."
        self.devices["FAN"]["is_on"] = True
        self.devices["FAN"]["speed"] = value
        return (
            f"Fan speed set to {value}/5 in ULTRON simulation mode. "
            "This is only a software demonstration; no physical fan was controlled."
        )

    def execute_natural_language(self, command: str) -> Optional[str]:
        """Handle home-control phrases; return None for unrelated messages."""
        text = self._normalise(command)
        if not text:
            return None

        # Fan speed command, e.g. "set fan speed to 3" or "fan speed 2".
        if "fan" in text:
            speed_match = re.search(
                r"\b(?:set\s+)?(?:the\s+)?fan\b.*?\b(?:speed|level)\s*(?:to|at)?\s*(\d+)\b",
                text,
            )
            if speed_match:
                return self.set_fan_speed(speed_match.group(1))

        device = self._find_device(text)
        is_status_question = (
            any(term in text for term in ("status", "what state", "are the", "is the", "is my", "are my"))
            or text.startswith(("what is", "what's", "tell me", "check"))
            or "?" in text
        )
        if device and is_status_question:
            state = self.devices[device]
            power = "ON" if state["is_on"] else "OFF"
            extra = f", speed {state['speed']}/5" if device == "FAN" else ""
            return (
                f"{device} is {power}{extra} in ULTRON simulation mode. "
                "Physical device status is unavailable because no controller is connected."
            )

        if not device:
            if any(word in text for word in ("home status", "appliance status", "device status", "home devices")):
                return self.status_text()
            return None

        # Recognise explicit power actions in either common word order.
        action = None
        if re.search(r"\b(turn|switch|power)\s+on\b", text) or re.search(
            r"\b(activate|enable|start)\b", text
        ):
            action = True
        elif re.search(r"\b(turn|switch|power)\s+off\b", text) or re.search(
            r"\b(deactivate|disable|stop)\b", text
        ):
            action = False
        else:
            alias_pattern = "|".join(re.escape(x) for x in self.DEVICES[device])
            if re.search(rf"\b(?:{alias_pattern})\s+(?:on)\b", text) or re.search(
                rf"\bon\s+(?:the\s+)?(?:{alias_pattern})\b", text
            ):
                action = True
            elif re.search(rf"\b(?:{alias_pattern})\s+(?:off)\b", text) or re.search(
                rf"\boff\s+(?:the\s+)?(?:{alias_pattern})\b", text
            ):
                action = False

        if action is None:
            if device == "FAN" and re.search(r"\b(speed|level)\b", text):
                return "Please specify a fan speed from 1 to 5, for example: set fan speed to 3."
            return (
                f"I found {device}. Say 'turn on the {device.lower()}' or "
                f"'turn off the {device.lower()}'."
            )
        return self.set_device(device, action)
