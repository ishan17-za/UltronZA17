class RobotController:

    def __init__(self):
        self.connected = False
        self.current_command = "STOP"

    def send_command(self, command):
        allowed_commands = [
            "FORWARD",
            "BACKWARD",
            "LEFT",
            "RIGHT",
            "STOP"
        ]

        if command not in allowed_commands:
            return "Invalid robot command"

        self.current_command = command

        if not self.connected:
            return f"Controller ready. {command} stored locally."

        # Hardware communication will be added later.
        return f"Command sent: {command}"

    def emergency_stop(self):
        self.current_command = "STOP"
        return "EMERGENCY STOP"