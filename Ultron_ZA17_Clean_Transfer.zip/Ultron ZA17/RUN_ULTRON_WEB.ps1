﻿$env:ULTRON_WEB_KEY='jRkOz7vGVgIZbrM1uHwl'
$env:OLLAMA_MODEL='qwen2.5:1.5b'
Set-Location 'D:\Ultron ZA17'
& '.\.venv\Scripts\python.exe' -m uvicorn web_app.server:app --host 0.0.0.0 --port 8000
