import json, os, urllib.request, asyncio
from pathlib import Path
from fastapi import FastAPI, HTTPException, Header
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
ROOT=Path(__file__).resolve().parent
KEY=os.environ.get("ULTRON_WEB_KEY","CHANGE-THIS-KEY")
MODEL=os.environ.get("OLLAMA_MODEL","qwen2.5:1.5b")
app=FastAPI(title="ULTRON ZA17")
app.mount("/static",StaticFiles(directory=ROOT/"static"),name="static")
class Login(BaseModel): key:str
class Chat(BaseModel): message:str; history:list=[]
@app.get("/")
def home(): return FileResponse(ROOT/"static"/"index.html")
@app.post("/api/login")
def login(x:Login):
    if x.key!=KEY: raise HTTPException(401,"Incorrect access key")
    return {"ok":True}
@app.post("/api/chat")
async def chat(x:Chat,x_ultron_key:str=Header(default="")):
    if x_ultron_key!=KEY: raise HTTPException(401,"Sign in again")
    msgs=[{"role":"system","content":"You are ULTRON ZA17, a helpful and safe AI assistant."}]
    for m in x.history[-10:]:
        if isinstance(m,dict) and m.get("role") in ("user","assistant"): msgs.append({"role":m["role"],"content":str(m.get("content",""))[:4000]})
    msgs.append({"role":"user","content":x.message[:4000]})
    req=urllib.request.Request("http://127.0.0.1:11434/api/chat",data=json.dumps({"model":MODEL,"messages":msgs,"stream":False}).encode(),headers={"Content-Type":"application/json"})
    try:
        def call():
            with urllib.request.urlopen(req,timeout=120) as r:return json.loads(r.read().decode())
        out=await asyncio.to_thread(call)
        return {"reply":out.get("message",{}).get("content","No response")}
    except Exception as e: raise HTTPException(502,f"Ollama connection failed: {e}")
@app.get("/api/health")
def health(): return {"status":"online","model":MODEL}
